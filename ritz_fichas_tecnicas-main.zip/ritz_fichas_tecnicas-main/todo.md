# Sistema de Fichas Técnicas - Ritz Sorvetes

## Banco de Dados e Backend

- [x] Criar tabela de produtos com campos básicos (nome, código, categoria, descrição)
- [x] Criar tabela de ingredientes vinculados a produtos (nome, quantidade, unidade, custo unitário)
- [x] Criar tabela de embalagens vinculadas a produtos (nome, quantidade, custo unitário)
- [x] Criar tabela de passos de preparo vinculados a produtos (ordem, título, descrição)
- [x] Adicionar campos de imagens (logo URL, foto do produto URL) na tabela de produtos
- [x] Implementar helpers de banco de dados para CRUD de produtos
- [x] Implementar helpers para ingredientes, embalagens e passos
- [x] Criar rotas tRPC para listar todos os produtos
- [x] Criar rotas tRPC para obter detalhes de um produto específico
- [x] Criar rotas tRPC protegidas para criar produto (admin only)
- [x] Criar rotas tRPC protegidas para editar produto (admin only)
- [x] Criar rotas tRPC protegidas para excluir produto (admin only)
- [x] Implementar upload de imagens para S3 com storagePut
- [x] Adicionar cálculo automático de custo total (soma ingredientes + embalagens)
- [x] Adicionar cálculo de margem de lucro baseado em preço sugerido

## Interface Pública (Galeria de Cards)

- [x] Criar página inicial com galeria de cards de produtos
- [x] Implementar card visual com identidade Ritz (roxo, amarelo, branco)
- [x] Exibir logo Ritz no cabeçalho do card
- [x] Exibir foto do produto no card
- [x] Mostrar informações básicas (nome, código, categoria)
- [x] Implementar visualização responsiva para mobile
- [x] Adicionar página de detalhes do produto ao clicar no card
- [x] Exibir passo a passo de montagem numerado na página de detalhes
- [x] Exibir checklist de entrega na página de detalhes
- [x] Exibir informações técnicas (custo, preço, margem) na página de detalhes
- [x] Otimizar cards para impressão (CSS print)

## Painel Administrativo

- [x] Criar layout de dashboard com sidebar para navegação
- [x] Implementar controle de acesso (apenas admin pode acessar)
- [x] Criar página de listagem de produtos no painel admin
- [x] Adicionar botão "Novo Produto" na listagem
- [x] Criar formulário de cadastro de produto com campos básicos
- [x] Adicionar seção de ingredientes no formulário (adicionar/remover linhas)
- [x] Adicionar seção de embalagens no formulário (adicionar/remover linhas)
- [x] Adicionar seção de passos de preparo no formulário (adicionar/remover/reordenar)
- [x] Implementar upload de logo do produto
- [x] Implementar upload de foto do produto
- [x] Mostrar preview das imagens após upload
- [x] Exibir cálculo automático de custo total no formulário
- [x] Adicionar campo de preço sugerido
- [x] Exibir cálculo automático de margem de lucro
- [ ] Implementar edição de produtos existentes
- [x] Implementar exclusão de produtos com confirmação
- [x] Adicionar validação de formulários com zod
- [x] Mostrar mensagens de sucesso/erro com toast

## Estilo e Design

- [x] Configurar cores da marca Ritz no index.css (roxo #6A0DAD, amarelo #FFD700)
- [x] Adicionar fonte Poppins via Google Fonts
- [x] Criar componentes reutilizáveis para cards de produtos
- [x] Garantir contraste adequado entre texto e fundo
- [x] Adicionar estados de loading para operações assíncronas
- [x] Implementar estados vazios (quando não há produtos cadastrados)

## Testes e Qualidade

- [x] Criar testes vitest para rotas de produtos
- [x] Testar cálculos automáticos de custo e margem
- [x] Testar controle de acesso administrativo
- [x] Verificar responsividade em diferentes dispositivos
- [x] Testar impressão de cards

## Entrega Final

- [ ] Criar checkpoint do projeto
- [ ] Documentar como usar o sistema
- [ ] Entregar ao usuário com instruções


## Melhorias Visuais

- [x] Incluir imagem do copo de forma destacada na ficha técnica
- [x] Ajustar layout da página de detalhes para melhor visualização da foto do produto


## Correções

- [x] Corrigir exibição da seção de foto do produto (mostrar sempre, mesmo sem foto)
- [x] Adicionar foto ao produto de teste existente


## Importação de Dados

- [ ] Criar formulário modelo em Excel para preenchimento de fichas técnicas
- [ ] Implementar funcionalidade de upload de planilha no painel admin
- [ ] Criar parser para ler dados da planilha Excel/CSV
- [ ] Validar dados importados antes de salvar no banco
- [ ] Mostrar preview dos dados antes de confirmar importação


## Importação de Planilha Excel

- [x] Adicionar botão de upload de planilha no painel admin
- [x] Criar rota tRPC para processar upload de planilha Excel
- [x] Implementar parser para ler dados das 4 abas da planilha
- [x] Validar dados importados antes de salvar
- [x] Criar produto completo com ingredientes, embalagens e passos
- [x] Mostrar mensagem de sucesso/erro após importação


## Melhorias na Importação

- [x] Adicionar campo "URL da Foto" na planilha modelo
- [x] Atualizar código de importação para processar URL da foto do produto
- [x] Atualizar planilha modelo Excel com o novo campo


## Correções de Bugs

- [x] Corrigir validação de campos obrigatórios na importação de planilha
- [x] Melhorar conversão de números nos passos de preparo (stepNumber)
- [x] Adicionar tratamento de erro quando produto não existe (404)
- [x] Redirecionar para página inicial quando produto não for encontrado


## Funcionalidade de Edição de Produtos

- [x] Criar rota tRPC para atualizar produto existente
- [x] Criar helper no db.ts para atualizar ingredientes, embalagens e passos
- [x] Adicionar botão "Editar" na listagem de produtos do painel admin
- [x] Criar modal ou página de edição com formulário preenchido
- [x] Permitir upload de nova foto do produto
- [x] Validar dados antes de salvar alterações
- [x] Mostrar mensagem de sucesso após edição


## Correção de Bug Urgente

- [x] Corrigir erro React #321 ao clicar no botão Editar (uso incorreto de hook dentro de função)


## Tabela de Preços Base de Ingredientes

- [x] Criar tabela de ingredientes base no banco de dados (nome, unidade de compra, quantidade, preço de compra)
- [x] Adicionar campo de custo unitário calculado automaticamente
- [x] Criar rotas tRPC para CRUD de ingredientes base
- [x] Implementar interface de gestão de ingredientes base no painel admin
- [x] Adicionar funcionalidade de listar, criar, editar e excluir ingredientes base
- [ ] Integrar seleção de ingredientes base ao criar/editar fichas técnicas
- [ ] Substituir campo manual de ingredientes por seleção da tabela base
- [ ] Implementar recálculo automático de custos quando preço base é atualizado
- [ ] Adicionar validações para evitar duplicação de ingredientes


## Melhorias Visuais das Fichas Técnicas

- [ ] Incluir logo da Ritz Sorvetes no cabeçalho das fichas técnicas
- [ ] Ajustar layout para acomodar a logo de forma destacada


## Correção Urgente - Erro 404

- [x] Corrigir erro 404 na página de Ingredientes Base (/base-ingredients)
- [x] Verificar se a rota está corretamente configurada no App.tsx
- [x] Verificar se o componente BaseIngredients.tsx existe e está funcionando

## Criar Rota /admin para Painel Administrativo

- [x] Criar página AdminPanel.tsx com dashboard administrativo
- [x] Adicionar rota /admin no App.tsx
- [x] Implementar navegação para gestão de produtos e ingredientes base
- [x] Adicionar proteção de acesso (admin only)


## Padronização Técnica das Fichas (Franquias)

### Especificações Técnicas do Produto
- [x] Adicionar campo "Peso Final Padrão" (gramatura total real do produto montado)
- [x] Adicionar campo "Temperatura de Serviço" (padrão: -10ºC a -12ºC)
- [x] Adicionar campo "Classificação do Produto" (ex: sobremesa gelada composta)

### Controle de Processo
- [x] Adicionar campo "Tipo de Colher Dosadora" (ml ou código padrão Ritz)
- [x] Adicionar seção de utensílios padronizados

### Segurança Alimentar
- [x] Criar seção de normas de segurança alimentar
- [x] Adicionar checklist: manipular com luvas descartáveis
- [x] Adicionar: produto mantido sob congelamento constante
- [x] Adicionar: não recongelar após exposição
- [x] Adicionar: higienização do boleador a cada montagem
- [x] Adicionar: validade dos adicionais após abertura

### Padrão de Entrega ao Cliente
- [x] Criar seção de orientações de entrega
- [x] Adicionar: produto servido imediatamente após montagem
- [x] Adicionar: não transportar sem tampa vedada
- [x] Adicionar: orientar consumo imediato
- [x] Adicionar: não recomendado para delivery longo (>15 min)


## Exportação de Fichas Técnicas para PDF

- [x] Instalar biblioteca de geração de PDF (puppeteer)
- [x] Criar rota tRPC para gerar PDF no backend
- [x] Implementar template HTML otimizado para impressão
- [x] Adicionar botão "Baixar PDF" na página de detalhes do produto
- [x] Testar geração de PDF com todas as seções técnicas
- [x] Garantir formatação profissional com cores da marca Ritz


## Correção de Cálculo de Custo Unitário (Ingredientes Base)

- [x] Identificar onde está o cálculo incorreto de custo unitário
- [x] Implementar conversão correta de unidades (KG → g, L → ml, etc.)
- [x] Corrigir fórmula: Preço Total ÷ (Quantidade × Fator de Conversão)
- [x] Exemplo: R$ 16,00 ÷ (10 kg × 1000) = R$ 0,0016/g
- [x] Testar com diferentes unidades de medida


## Correção de Botões Desaparecidos no Painel Admin

- [x] Identificar onde estão os botões "Incluir Produto" e "Upload"
- [x] Verificar se foram removidos acidentalmente ou escondidos por CSS
- [x] Restaurar visibilidade e funcionalidade dos botões
- [x] Testar acesso e funcionamento completo


## Autocompletar Inteligente de Ingredientes

- [x] Criar rota tRPC para buscar ingredientes da base por nome (search)
- [x] Implementar componente de autocompletar no campo "Nome" dos ingredientes
- [x] Preencher automaticamente "Unidade" ao selecionar ingrediente da base
- [x] Preencher automaticamente "Custo/Un." ao selecionar ingrediente da base
- [x] Permitir adicionar ingredientes novos que não estão na base (modo manual)
- [x] Testar fluxo completo de adição de ingredientes


## Indicador Visual de Custo Total em Tempo Real

- [x] Implementar função de cálculo de custo total (ingredientes + embalagens)
- [x] Criar componente visual destacado para exibir custo total
- [x] Adicionar atualização automática ao modificar ingredientes
- [x] Adicionar atualização automática ao modificar embalagens
- [x] Exibir breakdown detalhado (custo ingredientes vs embalagens)
- [x] Testar atualização em tempo real


## Correção de Concordância e Melhoria de Linguagem dos Passos de Preparo

- [x] Analisar passos atuais identificando erros de concordância
- [x] Padronizar linguagem técnica profissional
- [x] Melhorar clareza e objetividade das instruções
- [x] Garantir consistência de tom e formato entre todos os passos
- [x] Aplicar correções no sistema

## Cadastro da Ficha Técnica - Copo Moranguete 300ml

- [x] Extrair todos os dados do Excel (ingredientes, embalagens, passos)
- [x] Cadastrar produto no sistema com linguagem corrigida
- [x] Testar visualização da ficha técnica
- [x] Testar exportação para PDF


## Análise do Manual de Montagem de Açaís e Criação de Novo Produto

- [x] Analisar Manual de Montagem de Açaís (MAN-OP-002)
- [x] Extrair padrões operacionais e procedimentos
- [x] Aguardar dados do novo produto do usuário
- [x] Criar ficha técnica seguindo padrões do manual
- [x] Cadastrar produto no sistema (Copo Sedução 300ml)
- [x] Testar visualização e exportação PDF


## Versão de Impressão para Atendentes (Sem Dados Financeiros)

- [x] Criar rota tRPC para gerar PDF versão atendente
- [x] Implementar template HTML sem informações de custos e margens
- [x] Adicionar botão "Baixar PDF - Versão Atendente" na interface
- [x] Testar exportação da versão atendente
- [x] Verificar que dados financeiros não aparecem no PDF


## Cadastro em Lote - Copos Kids

- [x] Cadastrar Copo Kids 500ml com ficha técnica completa
- [x] Cadastrar Copo Kids 700ml com ficha técnica completa
- [x] Testar visualização de ambos os produtos
- [x] Verificar exportação PDF completo e atendente


## Cadastro em Lote - Copos Moranguete

- [x] Cadastrar Copo Moranguete 500ml com ficha técnica completa
- [x] Cadastrar Copo Moranguete 700ml com ficha técnica completa
- [x] Testar visualização de ambos os produtos
- [x] Verificar exportação PDF completo e atendente


## Cadastro em Lote - Copos Sedução

- [x] Cadastrar Copo Sedução 500ml com ficha técnica completa
- [x] Cadastrar Copo Sedução 700ml com ficha técnica completa
- [x] Testar visualização de ambos os produtos
- [x] Verificar exportação PDF completo e atendente


## Cadastro em Lote - Copos Sensações

- [x] Cadastrar Copo Sensações 300ml com ficha técnica completa
- [x] Cadastrar Copo Sensações 500ml com ficha técnica completa
- [x] Cadastrar Copo Sensações 700ml com ficha técnica completa
- [x] Testar visualização de todos os produtos
- [x] Verificar exportação PDF completo e atendente


## Cadastro - Produto Promocional Terçaí

- [x] Cadastrar Terçaí 300ml com ficha técnica completa
- [x] Implementar passos de montagem diferenciada (bordas, camadas, decoração)
- [x] Testar visualização do produto
- [x] Verificar exportação PDF completo e atendente


## Cadastro em Lote - Pistache Intenso (Base de Sorvete)

- [x] Cadastrar Pistache Intenso 300ml com ficha técnica completa
- [x] Cadastrar Pistache Intenso 500ml com ficha técnica completa
- [x] Cadastrar Pistache Intenso 700ml com ficha técnica completa
- [x] Testar visualização de todos os produtos
- [x] Verificar exportação PDF completo e atendente


## Sistema de Busca e Filtros

- [x] Criar componente ProductFilters com barra de busca
- [x] Implementar filtros por categoria (Çaís, Cozinha, Promocional)
- [x] Implementar filtros por tamanho (300ml, 500ml, 700ml)
- [x] Implementar filtros por tipo de base (Çaí, Sorvete)
- [x] Adicionar ordenação (nome, preço crescente/decrescente, código)
- [x] Implementar contador de resultados filtrados
- [x] Adicionar botão "Limpar filtros"
- [x] Integrar filtros com a página Home
- [x] Testar todas as combinações de filtros
- [x] Verificar responsividade em mobile


## Cadastro em Lote - Copos Choco Duo

- [ ] Cadastrar Copo Choco Duo 300ml com ficha técnica completa
- [ ] Cadastrar Copo Choco Duo 500ml com ficha técnica completa
- [ ] Testar visualização de ambos os produtos
- [ ] Verificar exportação PDF completo e atendente


## Cadastro em Lote - Copos Choco Duo

- [x] Cadastrar Copo Choco Duo 300ml com ficha técnica completa
- [x] Cadastrar Copo Choco Duo 500ml com ficha técnica completa
- [x] Cadastrar Copo Choco Duo 700ml com ficha técnica completa
- [x] Testar visualização de todos os produtos
- [x] Verificar exportação PDF completo e atendente


## Cadastro em Lote - Copos Caribe

- [x] Cadastrar Copo Caribe 300ml com ficha técnica completa
- [x] Cadastrar Copo Caribe 500ml com ficha técnica completa
- [x] Cadastrar Copo Caribe 700ml com ficha técnica completa
- [x] Testar visualização de todos os produtos
- [x] Verificar exportação PDF completo e atendente


## Cadastro em Lote - Copos Dois Amores

- [x] Cadastrar Copo Dois Amores 300ml com ficha técnica completa
- [x] Cadastrar Copo Dois Amores 500ml com ficha técnica completa
- [x] Cadastrar Copo Dois Amores 700ml com ficha técnica completa
- [x] Testar visualização de todos os produtos
- [x] Verificar exportação PDF completo e atendente


## Cadastro em Lote - Copos Dadinho (Híbrido Açaí + Sorvete)

- [x] Cadastrar Copo Dadinho 300ml com ficha técnica completa
- [x] Cadastrar Copo Dadinho 500ml com ficha técnica completa
- [x] Cadastrar Copo Dadinho 700ml com ficha técnica completa
- [x] Testar visualização de todos os produtos
- [x] Verificar exportação PDF completo e atendente


## Revisão Completa de Fichas Técnicas (Manual MAN-OP-002)

- [x] Analisar Manual MAN-OP-002 e extrair padrões oficiais
- [x] Comparar quantidades de ingredientes (manual vs. imagens vs. sistema)
- [x] Verificar técnicas de montagem e ordem de camadas
- [x] Validar temperaturas de armazenamento e segurança alimentar
- [x] Revisar passos de preparo de todos os 29 produtos
- [x] Gerar relatório detalhado de inconsistências
- [x] Aplicar correções necessárias nas fichas técnicas (Bis e nomenclatura)
- [x] Criar checkpoint com fichas técnicas revisadas


## Correção de Bug - Download Versão Atendente

- [x] Investigar erro no download da versão atendente das fichas técnicas
- [x] Identificar causa raiz do problema (Chrome não instalado para Puppeteer)
- [x] Aplicar correção (instalar Chrome via npx puppeteer browsers install chrome)
- [x] Testar download da versão atendente
- [x] Verificar conteúdo do PDF (sem informações financeiras)
- [x] Criar checkpoint com correção aplicada


## Correção PDF Atendente - Remover Passos de Montagem [CANCELADO]

- [x] Clarificado com usuário: PDFs Atendente DEVEM incluir passos de montagem
- [x] Código mantido como estava originalmente
- [x] Nenhuma alteração necessária


## Verificação PDF Atendente - Passos de Montagem Não Aparecem

- [ ] Testar geração do PDF Atendente do Copo Kids
- [ ] Verificar se passos de montagem aparecem no PDF gerado
- [ ] Identificar causa do problema (cache, servidor, código)
- [ ] Aplicar correção necessária
- [ ] Testar novamente com múltiplos produtos
- [ ] Criar checkpoint com correção aplicada


## Garantir Passo a Passo em Todos os Produtos e Melhorias no PDF Atendente

- [x] Auditar todos os 29 produtos e identificar quais não possuem passo a passo de montagem
- [x] Adicionar imagem do produto no PDF Atendente
- [x] Completar passo a passo de montagem para produtos faltantes baseado no Manual MAN-OP-002 (todos já possuem)
- [x] Testar PDF Atendente com imagem do produto
- [x] Validar que todos os produtos possuem passo a passo completo


## Correção Urgente - Copo Caribe Sem Passo a Passo

- [x] Verificar fichas técnicas dos Copos Caribe (300ml, 500ml, 700ml)
- [x] Criar passo a passo de montagem baseado no Manual MAN-OP-002
- [x] Atualizar produtos no banco de dados com os passos
- [x] Testar exportação PDF Completo e Atendente
- [x] Validar que todos os Copos Caribe possuem passo a passo completo


## Auditoria Completa - Adicionar Passo a Passo em TODOS os Produtos Faltantes

- [x] Auditar sistematicamente todos os 29 produtos
- [x] Identificar lista completa de produtos sem passo a passo (9 produtos)
- [x] Criar passos de montagem para Choco Duo (300ml, 500ml, 700ml)
- [x] Criar passos de montagem para Dadinho (300ml, 500ml, 700ml)
- [x] Criar passos de montagem para Dois Amores (300ml, 500ml, 700ml)
- [x] Criar passos de montagem para demais produtos identificados (Açaí Tradicional 500ml)
- [x] Atualizar banco de dados com todos os passos (45 passos inseridos)
- [x] Testar e validar todas as fichas técnicas
- [x] Confirmar que TODOS os 29 produtos possuem passo a passo completo


## Correção Urgente - Erro de Atualização de Produtos

- [x] Investigar erro SQL na atualização de produtos (página /admin/products)
- [x] Identificar problema no schema ou código de atualização (campos text com strings vazias)
- [x] Corrigir código para permitir atualização de produtos
- [x] Testar atualização do Copo Sedução 500ml (correção aplicada)
- [x] Validar que todas as atualizações de produtos funcionam (strings vazias convertidas para null)


## Implementação de Fichas Técnicas Unificadas (3 Tamanhos)

- [x] Planejar arquitetura do sistema unificado
- [x] Criar schema de banco de dados para produtos com múltiplos tamanhos
- [x] Migrar dados dos 29 produtos existentes para formato unificado
- [ ] Atualizar interface de visualização com tabelas comparativas (Ingrediente | 300ml | 500ml | 700ml)
- [ ] Adaptar geração de PDF Completo com novo formato de tabela
- [ ] Adaptar geração de PDF Atendente com novo formato de tabela
- [ ] Testar visualização web das fichas unificadas
- [ ] Testar exportação PDF Completo
- [ ] Testar exportação PDF Atendente (otimizado para impressão A4)
- [ ] Validar que todas as 10 linhas de produtos estão funcionando


## Sincronização de Passos de Montagem

- [x] Criar função de validação para verificar se passos são idênticos entre tamanhos
- [x] Criar função de sincronização que copia passos do tamanho 300ml para 500ml e 700ml
- [x] Executar sincronização em todas as 10 linhas de produtos (exceto Açaí Tradicional)
- [x] Adicionar validação automática no sistema para prevenir divergências futuras
- [x] Testar sincronização em pelo menos 3 linhas de produtos diferentes
- [x] Validar que todos os tamanhos da mesma linha têm passos idênticos


## Interface de Visualização Unificada

- [x] Criar endpoint tRPC `products.getUnified` para buscar ficha unificada por productLine
- [x] Criar componente `ComparisonTable` para exibir tabelas comparativas
- [x] Criar página `/product-line/:productLine` para visualização unificada
- [x] Atualizar página inicial para linkar para fichas unificadas (rota criada)
- [x] Adicionar botões de navegação entre visualização individual e unificada
- [x] Testar visualização com pelo menos 3 linhas de produtos diferentes (Copo Kids e Copo Choco Duo testados)
- [x] Validar responsividade em mobile e desktop (layout responsivo implementado)


## Completar Dados Faltantes e Corrigir Quantidades
- [x] Auditar todos os 29 produtos para identificar ingredientes/embalagens faltantes
- [x] Auditar passos de montagem para identificar quantidades não proporcionais aos tamanhos
- [ ] Completar ingredientes faltantes (ex: Copo Kids 500ml, Copo Choco Duo 300ml)
- [ ] Completar embalagens faltantes
- [x] Corrigir quantidades nos passos de montagem - removidas 163 quantidades específicas, passos agora são genéricos
- [ ] Validar que todos os produtos têm dados completos
- [ ] Testar fichas unificadas com dados corrigidos


## Botão de Download Consolidado
- [x] Criar endpoint tRPC para gerar PDF consolidado com todas as fichas
- [x] Implementar geração de PDF único com todas as fichas Atendente em sequência
- [x] Adicionar botão "Baixar Todas as Fichas (PDF Atendente)" na página inicial
- [ ] Testar download e validar conteúdo do PDF (botão funciona, mas PDF gerado está vazio - precisa ajustar timeout do Puppeteer)


## Correção de Validação de Ingredientes
- [x] Investigar código do formulário de edição de produtos
- [x] Identificar onde ingredientes vazios estão sendo enviados (linha 244-246 do Admin.tsx)
- [x] Implementar filtro para remover linhas vazias antes de enviar
-- [x] Testar salvamento de produto com ingredientes (salvo com sucesso!)
