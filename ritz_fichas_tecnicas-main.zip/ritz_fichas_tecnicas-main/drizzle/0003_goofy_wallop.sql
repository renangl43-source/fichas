ALTER TABLE `products` ADD `finalWeight` varchar(100);--> statement-breakpoint
ALTER TABLE `products` ADD `servingTemperature` varchar(100);--> statement-breakpoint
ALTER TABLE `products` ADD `productClassification` varchar(255);--> statement-breakpoint
ALTER TABLE `products` ADD `scoopType` varchar(100);--> statement-breakpoint
ALTER TABLE `products` ADD `foodSafetyNotes` text;--> statement-breakpoint
ALTER TABLE `products` ADD `deliveryStandards` text;