CREATE TABLE `base_ingredients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`purchase_unit` varchar(50) NOT NULL,
	`purchase_quantity` int NOT NULL,
	`purchase_price` int NOT NULL,
	`usage_unit` varchar(50) NOT NULL,
	`unit_cost` int NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `base_ingredients_id` PRIMARY KEY(`id`)
);
