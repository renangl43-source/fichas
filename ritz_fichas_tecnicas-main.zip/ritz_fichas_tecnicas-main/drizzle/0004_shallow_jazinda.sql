ALTER TABLE `products` ADD `productLine` varchar(100);--> statement-breakpoint
ALTER TABLE `products` ADD `size` varchar(20);