import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tabela de ingredientes base com preços de compra.
 * Serve como catálogo centralizado para precificação consistente.
 */
export const baseIngredients = mysqlTable("base_ingredients", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  /** Unidade de compra (ex: kg, caixa, litro) */
  purchaseUnit: varchar("purchase_unit", { length: 50 }).notNull(),
  /** Quantidade na unidade de compra (ex: 10 para caixa de 10kg) */
  purchaseQuantity: int("purchase_quantity").notNull(),
  /** Preço de compra total (ex: R$ 160,00 para caixa de 10kg) */
  purchasePrice: int("purchase_price").notNull(), // em centavos
  /** Unidade de uso nas fichas técnicas (ex: g, ml) */
  usageUnit: varchar("usage_unit", { length: 50 }).notNull(),
  /** Custo unitário calculado (custo por unidade de uso) */
  unitCost: int("unit_cost").notNull(), // em centavos por unidade de uso
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type BaseIngredient = typeof baseIngredients.$inferSelect;
export type InsertBaseIngredient = typeof baseIngredients.$inferInsert;

/**
 * Products table stores main product information
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  code: varchar("code", { length: 100 }).notNull().unique(),
  category: varchar("category", { length: 100 }).notNull(),
  
  // Agrupamento para fichas unificadas
  productLine: varchar("productLine", { length: 100 }), // Agrupa produtos da mesma linha (ex: "copo-kids")
  size: varchar("size", { length: 20 }), // Tamanho específico (ex: "300ml", "500ml", "700ml")
  description: text("description"),
  logoUrl: text("logoUrl"),
  photoUrl: text("photoUrl"),
  suggestedPrice: decimal("suggestedPrice", { precision: 10, scale: 2 }),
  
  // Especificações Técnicas
  finalWeight: varchar("finalWeight", { length: 100 }), // Peso final padrão (ex: "350g")
  servingTemperature: varchar("servingTemperature", { length: 100 }), // Temperatura ideal (ex: "-10ºC a -12ºC")
  productClassification: varchar("productClassification", { length: 255 }), // Classificação (ex: "sobremesa gelada composta")
  
  // Controle de Processo
  scoopType: varchar("scoopType", { length: 100 }), // Tipo de colher dosadora (ex: "50ml" ou "Código Ritz #3")
  
  // Segurança Alimentar
  foodSafetyNotes: text("foodSafetyNotes"), // Normas de segurança alimentar
  
  // Padrão de Entrega
  deliveryStandards: text("deliveryStandards"), // Orientações de entrega ao cliente
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Ingredients table - stores ingredients for each product
 */
export const ingredients = mysqlTable("ingredients", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 50 }).notNull(),
  unitCost: decimal("unitCost", { precision: 10, scale: 2 }).notNull(),
  order: int("order").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Ingredient = typeof ingredients.$inferSelect;
export type InsertIngredient = typeof ingredients.$inferInsert;

/**
 * Packaging table - stores packaging items for each product
 */
export const packaging = mysqlTable("packaging", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unitCost: decimal("unitCost", { precision: 10, scale: 2 }).notNull(),
  order: int("order").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Packaging = typeof packaging.$inferSelect;
export type InsertPackaging = typeof packaging.$inferInsert;

/**
 * Preparation steps table - stores step-by-step instructions
 */
export const preparationSteps = mysqlTable("preparation_steps", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  stepNumber: int("stepNumber").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PreparationStep = typeof preparationSteps.$inferSelect;
export type InsertPreparationStep = typeof preparationSteps.$inferInsert;
