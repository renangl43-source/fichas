UPDATE products SET photoUrl = '/acai-sample.png' WHERE id = 1;
