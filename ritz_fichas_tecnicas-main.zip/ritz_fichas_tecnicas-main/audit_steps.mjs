import { getDb } from './server/db.js';

const db = getDb();

// Buscar todos os produtos
const products = db.select().from(await import('./drizzle/schema.js').then(m => m.products)).all();

console.log('=== AUDITORIA DE PASSOS DE MONTAGEM ===\n');
console.log(`Total de produtos: ${products.length}\n`);

let withSteps = 0;
let withoutSteps = 0;
const productsWithoutSteps = [];

for (const product of products) {
  const steps = db.select()
    .from(await import('./drizzle/schema.js').then(m => m.preparationSteps))
    .where((await import('drizzle-orm').then(m => m.eq))(
      (await import('./drizzle/schema.js').then(m => m.preparationSteps)).productId, 
      product.id
    ))
    .all();
  
  const stepCount = steps.length;
  
  if (stepCount > 0) {
    withSteps++;
    console.log(`✅ ${product.code} - ${product.name} (${stepCount} passos)`);
  } else {
    withoutSteps++;
    productsWithoutSteps.push({ code: product.code, name: product.name, id: product.id });
    console.log(`❌ ${product.code} - ${product.name} (SEM PASSOS)`);
  }
}

console.log(`\n=== RESUMO ===`);
console.log(`Produtos COM passo a passo: ${withSteps}`);
console.log(`Produtos SEM passo a passo: ${withoutSteps}`);

if (productsWithoutSteps.length > 0) {
  console.log(`\n=== PRODUTOS QUE PRECISAM DE PASSO A PASSO ===`);
  productsWithoutSteps.forEach(p => {
    console.log(`- ID ${p.id}: ${p.code} - ${p.name}`);
  });
}
