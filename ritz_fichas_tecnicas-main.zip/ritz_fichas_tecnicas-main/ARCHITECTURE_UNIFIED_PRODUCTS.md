# Arquitetura de Fichas Técnicas Unificadas

## Objetivo
Consolidar produtos que possuem 3 tamanhos (300ml, 500ml, 700ml) em uma única ficha técnica com tabela comparativa.

## Situação Atual
- **29 produtos individuais** no banco de dados
- Cada tamanho é um produto separado (ex: Copo Kids 300ml, Copo Kids 500ml, Copo Kids 700ml)
- Ingredientes, embalagens e passos duplicados para cada tamanho

## Situação Desejada
- **~10 fichas unificadas** (uma por linha de produto)
- Tabela comparativa com 4 colunas: `Ingrediente | 300ml | 500ml | 700ml`
- Passo a passo único (válido para todos os tamanhos)
- PDFs otimizados para impressão

---

## Modelo de Dados Proposto

### Abordagem Escolhida: **Manter Estrutura Atual + Agrupamento Lógico**

**Vantagens:**
- ✅ Não requer migração complexa do banco de dados
- ✅ Mantém compatibilidade com sistema atual
- ✅ Facilita relatórios e análises por tamanho
- ✅ Permite preços e custos diferentes por tamanho

**Como funciona:**
1. Produtos continuam individuais no banco (300ml, 500ml, 700ml)
2. Novo campo `productLine` agrupa produtos da mesma linha (ex: "copo-kids")
3. Interface e PDFs agrupam automaticamente por `productLine`
4. Apresentação unificada sem alterar estrutura de dados

---

## Estrutura de Tabelas

### Produtos (mantém estrutura atual)
```typescript
products {
  id: number
  name: string              // "Copo Kids 300ml"
  code: string              // "8"
  productLine: string       // NOVO: "copo-kids" (agrupa os 3 tamanhos)
  size: string              // NOVO: "300ml" | "500ml" | "700ml"
  category: string
  description: text
  photoUrl: string
  suggestedPrice: string
  // ... demais campos
}
```

### Ingredientes (mantém estrutura atual)
```typescript
ingredients {
  id: number
  productId: number         // FK para products
  name: string              // "Açaí"
  quantity: string          // "150g" (específico para cada tamanho)
  unitCost: string
  totalCost: string
}
```

### Embalagens (mantém estrutura atual)
```typescript
packaging {
  id: number
  productId: number
  name: string              // "Copo 300ml"
  quantity: string          // "1"
  unitCost: string
  totalCost: string
}
```

### Passos de Montagem (mantém estrutura atual)
```typescript
preparationSteps {
  id: number
  productId: number
  stepNumber: number
  title: string
  description: text
}
```

**Observação:** Os passos serão **idênticos** para os 3 tamanhos da mesma linha. Vamos garantir isso na migração.

---

## Linhas de Produtos Identificadas

1. **copo-kids** → Copo Kids (300ml, 500ml, 700ml)
2. **copo-moranguete** → Copo Moranguete (300ml, 500ml, 700ml)
3. **copo-seducao** → Copo Sedução (300ml, 500ml, 700ml)
4. **copo-sensacoes** → Copo Sensações (300ml, 500ml, 700ml)
5. **tercai** → Terçaí (300ml)
6. **pistache-intenso** → Pistache Intenso (300ml, 500ml, 700ml)
7. **copo-choco-duo** → Copo Choco Duo (300ml, 500ml, 700ml)
8. **copo-caribe** → Copo Caribe (300ml, 500ml, 700ml)
9. **copo-dois-amores** → Copo Dois Amores (300ml, 500ml, 700ml)
10. **copo-dadinho** → Copo Dadinho (300ml, 500ml, 700ml)
11. **acai-tradicional** → Açaí Tradicional (500ml) - produto único

---

## Interface de Visualização

### Página de Detalhes da Ficha Unificada

```
┌─────────────────────────────────────────────────────────┐
│  COPO KIDS                                    [PDF ▼]   │
│  Código: 8 | Categoria: cozinha                         │
│                                                          │
│  [Foto do produto]                                       │
│                                                          │
│  📋 INGREDIENTES                                         │
│  ┌──────────────────┬────────┬────────┬────────┐       │
│  │ Ingrediente      │ 300ml  │ 500ml  │ 700ml  │       │
│  ├──────────────────┼────────┼────────┼────────┤       │
│  │ Açaí             │ 150g   │ 250g   │ 350g   │       │
│  │ Leite em pó      │ 20g    │ 35g    │ 50g    │       │
│  │ ...              │ ...    │ ...    │ ...    │       │
│  └──────────────────┴────────┴────────┴────────┘       │
│                                                          │
│  📦 EMBALAGENS                                           │
│  ┌──────────────────┬────────┬────────┬────────┐       │
│  │ Embalagem        │ 300ml  │ 500ml  │ 700ml  │       │
│  ├──────────────────┼────────┼────────┼────────┤       │
│  │ Copo             │ 1 un   │ 1 un   │ 1 un   │       │
│  │ Colher           │ 1 un   │ 1 un   │ 1 un   │       │
│  └──────────────────┴────────┴────────┴────────┘       │
│                                                          │
│  👨‍🍳 PASSO A PASSO DE MONTAGEM                          │
│  1. Decoração do copo                                    │
│     Aplicar os confetes nas paredes internas...         │
│  2. Açaí - Fase 1                                        │
│     Adicionar açaí até 40% da altura do copo...         │
│  ...                                                     │
└─────────────────────────────────────────────────────────┘
```

---

## Geração de PDFs

### PDF Completo (Gerencial)
- Tabela de ingredientes com **custos unitários e totais** para cada tamanho
- Tabela de embalagens com **custos** para cada tamanho
- **Custo Total** para cada tamanho
- **Preço Sugerido** para cada tamanho
- **Margem de Lucro** para cada tamanho
- Passo a passo de montagem

### PDF Atendente (Operacional)
- Tabela de ingredientes **SEM custos** (só quantidades)
- Tabela de embalagens **SEM custos** (só quantidades)
- Passo a passo de montagem
- Foto do produto
- ❌ **SEM informações financeiras**
- Otimizado para impressão A4

---

## Plano de Migração

### Fase 1: Adicionar Campos ao Schema
```sql
ALTER TABLE products ADD COLUMN productLine VARCHAR(100);
ALTER TABLE products ADD COLUMN size VARCHAR(20);
```

### Fase 2: Atualizar Produtos Existentes
Mapear cada produto para sua linha e tamanho:
- "Copo Kids 300ml" → `productLine: "copo-kids"`, `size: "300ml"`
- "Copo Kids 500ml" → `productLine: "copo-kids"`, `size: "500ml"`
- "Copo Kids 700ml" → `productLine: "copo-kids"`, `size: "700ml"`

### Fase 3: Sincronizar Passos de Montagem
Garantir que os 3 tamanhos da mesma linha tenham passos idênticos (copiar do tamanho 300ml para 500ml e 700ml se necessário).

### Fase 4: Atualizar Interface
- Criar rota `/product-line/:productLine` para visualização unificada
- Manter rota `/product/:id` para compatibilidade

### Fase 5: Atualizar Geração de PDFs
- Modificar lógica para buscar os 3 tamanhos da mesma linha
- Gerar tabelas comparativas
- Manter passo a passo único

---

## Considerações Técnicas

### Vantagens da Abordagem
1. **Sem breaking changes** - sistema atual continua funcionando
2. **Migração incremental** - podemos testar linha por linha
3. **Flexibilidade** - fácil adicionar novos tamanhos (ex: 1L)
4. **Relatórios** - mantém granularidade por tamanho

### Desafios
1. **Sincronização de passos** - garantir que sejam idênticos
2. **Validação** - impedir que produtos da mesma linha tenham passos diferentes
3. **Interface admin** - decidir se edição será unificada ou individual

---

## Próximos Passos

1. ✅ Criar este documento de arquitetura
2. ⏳ Adicionar campos `productLine` e `size` ao schema
3. ⏳ Migrar dados dos 29 produtos
4. ⏳ Criar interface de visualização unificada
5. ⏳ Adaptar geração de PDFs
6. ⏳ Testar e validar
