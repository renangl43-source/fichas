import { drizzle } from 'drizzle-orm/mysql2';
import { eq } from 'drizzle-orm';
import { products } from './drizzle/schema.ts';

const db = drizzle(process.env.DATABASE_URL);

async function updateProductPhoto() {
  try {
    await db.update(products)
      .set({ photoUrl: '/acai-sample.png' })
      .where(eq(products.id, 1));
    console.log('Foto do produto atualizada com sucesso!');
  } catch (error) {
    console.error('Erro ao atualizar foto:', error);
  }
  process.exit(0);
}

updateProductPhoto();
