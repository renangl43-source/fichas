import { useState, useMemo } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { Loader2, Plus, Eye } from "lucide-react";
import { ProductFilters, ProductFiltersState } from "@/components/ProductFilters";
import { DownloadAllButton } from "@/components/DownloadAllButton";

export default function Home() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const { data: products, isLoading } = trpc.products.list.useQuery();

  // Filtros state
  const [filters, setFilters] = useState<ProductFiltersState>({
    search: "",
    category: "all",
    size: "all",
    baseType: "all",
    sortBy: "name-asc",
  });

  // Calculate total cost for a product
  const calculateTotalCost = (product: any) => {
    if (!product) return "0,00";
    
    const ingredientsCost = product.ingredients?.reduce((sum: number, ing: any) => {
      return sum + (parseFloat(ing.quantity) * parseFloat(ing.unitCost));
    }, 0) || 0;
    
    const packagingCost = product.packaging?.reduce((sum: number, pkg: any) => {
      return sum + (parseFloat(pkg.quantity) * parseFloat(pkg.unitCost));
    }, 0) || 0;
    
    const total = ingredientsCost + packagingCost;
    return total.toFixed(2).replace('.', ',');
  };

  // Aplicar filtros e ordenação
  const filteredProducts = useMemo(() => {
    if (!products) return [];

    let filtered = [...products];

    // Filtro de busca
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter((product) => {
        const nameMatch = product.name.toLowerCase().includes(searchLower);
        const codeMatch = product.code.toLowerCase().includes(searchLower);
        const ingredientsMatch = product.ingredients?.some((ing: any) =>
          ing.name.toLowerCase().includes(searchLower)
        );
        return nameMatch || codeMatch || ingredientsMatch;
      });
    }

    // Filtro de categoria
    if (filters.category !== "all") {
      filtered = filtered.filter((product) => product.category === filters.category);
    }

    // Filtro de tamanho
    if (filters.size !== "all") {
      filtered = filtered.filter((product) => {
        const sizeInName = product.name.toLowerCase().includes(`${filters.size}ml`);
        const sizeInCode = product.code.toLowerCase().includes(filters.size);
        return sizeInName || sizeInCode;
      });
    }

    // Filtro de tipo de base
    if (filters.baseType !== "all") {
      filtered = filtered.filter((product) => {
        const nameLower = product.name.toLowerCase();
        const hasAcai = product.ingredients?.some((ing: any) =>
          ing.name.toLowerCase().includes("açaí")
        );
        const hasSorvete = product.ingredients?.some((ing: any) =>
          ing.name.toLowerCase().includes("sorvete")
        );

        if (filters.baseType === "acai") {
          return hasAcai || nameLower.includes("açaí");
        } else if (filters.baseType === "sorvete") {
          return hasSorvete || nameLower.includes("pistache");
        }
        return true;
      });
    }

    // Ordenação
    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case "name-asc":
          return a.name.localeCompare(b.name);
        case "name-desc":
          return b.name.localeCompare(a.name);
        case "price-asc":
          return parseFloat(a.suggestedPrice || "0") - parseFloat(b.suggestedPrice || "0");
        case "price-desc":
          return parseFloat(b.suggestedPrice || "0") - parseFloat(a.suggestedPrice || "0");
        case "code-asc":
          return a.code.localeCompare(b.code);
        default:
          return 0;
      }
    });

    return filtered;
  }, [products, filters]);

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Header */}
      <header className="bg-ritz-purple text-white shadow-lg">
        <div className="container py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Ritz Sorvetes</h1>
              <p className="text-sm opacity-90 mt-1">Sistema de Fichas Técnicas</p>
            </div>
            <div className="flex items-center gap-4">
              {isAuthenticated ? (
                <>
                  <span className="text-sm">Olá, {user?.name}</span>
                  {user?.role === 'admin' && (
                    <Link href="/admin">
                      <Button variant="secondary" size="sm">
                        <Plus className="w-4 h-4 mr-2" />
                        Painel Admin
                      </Button>
                    </Link>
                  )}
                </>
              ) : (
                <a href={getLoginUrl()}>
                  <Button variant="secondary" size="sm">
                    Entrar
                  </Button>
                </a>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-2">Fichas Técnicas de Produtos</h2>
              <p className="text-muted-foreground">
                Consulte as fichas técnicas completas com ingredientes, modo de preparo e custos
              </p>
            </div>
            {isAuthenticated && products && products.length > 0 && (
              <DownloadAllButton />
            )}
          </div>
        </div>

        {/* Filtros */}
        {products && products.length > 0 && (
          <ProductFilters
            filters={filters}
            onFiltersChange={setFilters}
            resultCount={filteredProducts.length}
          />
        )}

        {/* Products Grid */}
        {!products || products.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <p className="text-muted-foreground mb-4">Nenhum produto cadastrado ainda.</p>
              {user?.role === 'admin' && (
                <Link href="/admin">
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Cadastrar Primeiro Produto
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>
        ) : filteredProducts.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Nenhum produto encontrado com os filtros aplicados.
              </p>
              <Button
                variant="outline"
                onClick={() =>
                  setFilters({
                    search: "",
                    category: "all",
                    size: "all",
                    baseType: "all",
                    sortBy: "name-asc",
                  })
                }
              >
                Limpar filtros
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow duration-200 overflow-hidden">
                {/* Product Image */}
                {product.photoUrl && (
                  <div className="h-48 bg-ritz-yellow flex items-center justify-center overflow-hidden">
                    <img
                      src={product.photoUrl}
                      alt={product.name}
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}
                
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <CardTitle className="text-lg line-clamp-2">{product.name}</CardTitle>
                      <CardDescription className="mt-1">
                        Código: {product.code}
                      </CardDescription>
                    </div>
                    {product.logoUrl && (
                      <img
                        src={product.logoUrl}
                        alt="Logo"
                        className="w-12 h-12 object-contain flex-shrink-0"
                      />
                    )}
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="space-y-2">
                    <Badge variant="secondary">{product.category}</Badge>
                    {product.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-2">
                        {product.description}
                      </p>
                    )}
                    <div className="pt-2 border-t">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Custo Total:</span>
                        <span className="font-semibold">R$ {calculateTotalCost(product)}</span>
                      </div>
                      {product.suggestedPrice && (
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-muted-foreground">Preço Sugerido:</span>
                          <span className="font-semibold text-primary">
                            R$ {parseFloat(product.suggestedPrice).toFixed(2).replace('.', ',')}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>

                <CardFooter>
                  <Link href={`/product/${product.id}`} className="w-full">
                    <Button className="w-full" variant="default">
                      <Eye className="w-4 h-4 mr-2" />
                      Ver Ficha Técnica
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-muted mt-16 py-6">
        <div className="container text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Ritz Sorvetes. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
