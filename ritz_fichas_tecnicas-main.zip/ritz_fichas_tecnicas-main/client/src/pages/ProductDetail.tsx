import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Link, useParams } from "wouter";
import { Loader2, ArrowLeft, Printer, CheckCircle2, Package, Download } from "lucide-react";
import { toast } from "sonner";

export default function ProductDetail() {
  const params = useParams<{ id: string }>();
  const productId = parseInt(params.id || "0");
  
  const { data: product, isLoading } = trpc.products.getById.useQuery(
    { id: productId },
    { enabled: productId > 0 }
  );

  // Calculate costs
  const calculateIngredientsCost = () => {
    if (!product?.ingredients) return 0;
    return product.ingredients.reduce((sum, ing) => {
      return sum + (parseFloat(ing.quantity) * parseFloat(ing.unitCost));
    }, 0);
  };

  const calculatePackagingCost = () => {
    if (!product?.packaging) return 0;
    return product.packaging.reduce((sum, pkg) => {
      return sum + (parseFloat(pkg.quantity) * parseFloat(pkg.unitCost));
    }, 0);
  };

  const totalCost = calculateIngredientsCost() + calculatePackagingCost();
  const suggestedPrice = product?.suggestedPrice ? parseFloat(product.suggestedPrice) : 0;
  const margin = suggestedPrice > 0 ? ((suggestedPrice - totalCost) / suggestedPrice) * 100 : 0;

  const exportPDFMutation = trpc.products.exportPDF.useMutation();
  const exportPDFAttendantMutation = trpc.products.exportPDFAttendant.useMutation();

  const handlePrint = () => {
    window.print();
    toast.success("Preparando impressão...");
  };

  const handleExportPDF = async () => {
    try {
      toast.loading("Gerando PDF...", { id: "pdf-export" });
      const result = await exportPDFMutation.mutateAsync({ id: productId });
      
      // Convert base64 to blob and download
      const byteCharacters = atob(result.pdfBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = result.filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success("PDF baixado com sucesso!", { id: "pdf-export" });
    } catch (error: any) {
      toast.error(error.message || "Erro ao gerar PDF", { id: "pdf-export" });
    }
  };

  const handleExportPDFAttendant = async () => {
    try {
      toast.loading("Gerando PDF versão atendente...", { id: "pdf-attendant-export" });
      const result = await exportPDFAttendantMutation.mutateAsync({ id: productId });
      
      // Convert base64 to blob and download
      const byteCharacters = atob(result.pdfBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = result.filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success("PDF versão atendente baixado com sucesso!", { id: "pdf-attendant-export" });
    } catch (error: any) {
      toast.error(error.message || "Erro ao gerar PDF", { id: "pdf-attendant-export" });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Produto não encontrado</p>
            <Link href="/">
              <Button>Voltar para Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header - Hidden on print */}
      <header className="bg-ritz-purple text-white shadow-lg no-print">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="secondary" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Ficha Técnica</h1>
            <div className="flex gap-2">
              <Button 
                variant="secondary" 
                size="sm" 
                onClick={handleExportPDF}
                disabled={exportPDFMutation.isPending}
              >
                {exportPDFMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Download className="w-4 h-4 mr-2" />
                )}
                PDF Completo
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleExportPDFAttendant}
                disabled={exportPDFAttendantMutation.isPending}
                className="bg-ritz-yellow hover:bg-ritz-yellow/90 text-ritz-purple border-ritz-yellow"
              >
                {exportPDFAttendantMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Download className="w-4 h-4 mr-2" />
                )}
                PDF Atendente
              </Button>
              <Button variant="secondary" size="sm" onClick={handlePrint}>
                <Printer className="w-4 h-4 mr-2" />
                Imprimir
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Product Card */}
      <main className="container py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="overflow-hidden">
            {/* Card Header with Logo */}
            <CardHeader className="bg-ritz-purple text-white">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <CardTitle className="text-2xl mb-2">{product.name}</CardTitle>
                  <p className="text-sm opacity-90">Código: {product.code}</p>
                </div>
                {product.logoUrl && (
                  <img
                    src={product.logoUrl}
                    alt="Logo"
                    className="w-16 h-16 object-contain bg-white rounded-lg p-2"
                  />
                )}
              </div>
            </CardHeader>

            {/* Product Photo */}
            <div className="bg-gradient-to-br from-ritz-yellow via-yellow-400 to-ritz-yellow p-8 flex items-center justify-center min-h-[400px] relative overflow-hidden">
              <div className="absolute inset-0 bg-[url('/copos-ritz.png')] bg-center bg-no-repeat bg-contain opacity-10"></div>
              {product.photoUrl ? (
                <img
                  src={product.photoUrl}
                  alt={product.name}
                  className="max-h-96 object-contain relative z-10 drop-shadow-2xl"
                />
              ) : (
                <div className="text-center text-ritz-purple/30 relative z-10">
                  <Package className="w-32 h-32 mx-auto mb-4" />
                  <p className="text-lg font-semibold">Foto do produto</p>
                </div>
              )}
            </div>

            <CardContent className="p-6 space-y-6">
              {/* Basic Info */}
              <div>
                <Badge variant="secondary" className="mb-2">{product.category}</Badge>
                {product.description && (
                  <p className="text-muted-foreground">{product.description}</p>
                )}
              </div>

              {/* Preparation Steps */}
              {product.steps && product.steps.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-ritz-purple mb-4 pb-2 border-b-2 border-ritz-yellow">
                    Passo a Passo de Montagem
                  </h3>
                  <div className="space-y-3">
                    {product.steps.map((step) => (
                      <div key={step.id} className="flex gap-3">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-ritz-purple text-white flex items-center justify-center font-bold text-sm">
                          {step.stepNumber}
                        </div>
                        <div className="flex-1 pt-1">
                          <h4 className="font-semibold text-sm mb-1">{step.title}</h4>
                          <p className="text-sm text-muted-foreground">{step.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Ingredients */}
              {product.ingredients && product.ingredients.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-ritz-purple mb-4 pb-2 border-b-2 border-ritz-yellow">
                    Ingredientes
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2 font-semibold">Ingrediente</th>
                          <th className="text-right py-2 font-semibold">Quantidade</th>
                          <th className="text-right py-2 font-semibold">Custo Unit.</th>
                          <th className="text-right py-2 font-semibold">Custo Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {product.ingredients.map((ing) => {
                          const itemCost = parseFloat(ing.quantity) * parseFloat(ing.unitCost);
                          return (
                            <tr key={ing.id} className="border-b">
                              <td className="py-2">{ing.name}</td>
                              <td className="text-right">{parseFloat(ing.quantity).toFixed(2).replace('.', ',')} {ing.unit}</td>
                              <td className="text-right">R$ {parseFloat(ing.unitCost).toFixed(2).replace('.', ',')}</td>
                              <td className="text-right font-semibold">R$ {itemCost.toFixed(2).replace('.', ',')}</td>
                            </tr>
                          );
                        })}
                        <tr className="font-bold">
                          <td colSpan={3} className="text-right py-2">Subtotal Ingredientes:</td>
                          <td className="text-right py-2">R$ {calculateIngredientsCost().toFixed(2).replace('.', ',')}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Packaging */}
              {product.packaging && product.packaging.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-ritz-purple mb-4 pb-2 border-b-2 border-ritz-yellow">
                    Embalagens
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2 font-semibold">Item</th>
                          <th className="text-right py-2 font-semibold">Quantidade</th>
                          <th className="text-right py-2 font-semibold">Custo Unit.</th>
                          <th className="text-right py-2 font-semibold">Custo Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {product.packaging.map((pkg) => {
                          const itemCost = parseFloat(pkg.quantity) * parseFloat(pkg.unitCost);
                          return (
                            <tr key={pkg.id} className="border-b">
                              <td className="py-2">{pkg.name}</td>
                              <td className="text-right">{parseFloat(pkg.quantity).toFixed(2).replace('.', ',')}</td>
                              <td className="text-right">R$ {parseFloat(pkg.unitCost).toFixed(2).replace('.', ',')}</td>
                              <td className="text-right font-semibold">R$ {itemCost.toFixed(2).replace('.', ',')}</td>
                            </tr>
                          );
                        })}
                        <tr className="font-bold">
                          <td colSpan={3} className="text-right py-2">Subtotal Embalagens:</td>
                          <td className="text-right py-2">R$ {calculatePackagingCost().toFixed(2).replace('.', ',')}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Especificações Técnicas do Produto */}
              {(product.finalWeight || product.servingTemperature || product.productClassification || product.scoopType) && (
                <div>
                  <h3 className="text-lg font-bold text-ritz-purple mb-4 pb-2 border-b-2 border-ritz-yellow">
                    Especificações Técnicas
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    {product.finalWeight && (
                      <div className="bg-muted p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Peso Final Padrão</p>
                        <p className="font-semibold">{product.finalWeight}</p>
                      </div>
                    )}
                    {product.servingTemperature && (
                      <div className="bg-muted p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Temperatura de Serviço</p>
                        <p className="font-semibold">{product.servingTemperature}</p>
                      </div>
                    )}
                    {product.productClassification && (
                      <div className="bg-muted p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Classificação</p>
                        <p className="font-semibold">{product.productClassification}</p>
                      </div>
                    )}
                    {product.scoopType && (
                      <div className="bg-muted p-3 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Colher Dosadora</p>
                        <p className="font-semibold">{product.scoopType}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Segurança Alimentar */}
              {product.foodSafetyNotes && (
                <div className="bg-red-50 border-2 border-red-200 p-4 rounded-lg">
                  <h3 className="text-lg font-bold text-red-700 mb-3 flex items-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    Segurança Alimentar
                  </h3>
                  <div className="text-sm text-red-900 whitespace-pre-line">
                    {product.foodSafetyNotes}
                  </div>
                </div>
              )}

              {/* Padrão de Entrega */}
              {product.deliveryStandards && (
                <div className="bg-blue-50 border-2 border-blue-200 p-4 rounded-lg">
                  <h3 className="text-lg font-bold text-blue-700 mb-3">
                    Padrão de Entrega ao Cliente
                  </h3>
                  <div className="text-sm text-blue-900 whitespace-pre-line">
                    {product.deliveryStandards}
                  </div>
                </div>
              )}

              {/* Checklist */}
              <div className="bg-muted p-4 rounded-lg">
                <h3 className="text-lg font-bold text-ritz-purple mb-3">
                  Checklist de Entrega
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-ritz-purple" />
                    <span>Produto montado conforme o padrão</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-ritz-purple" />
                    <span>Embalagem adequada</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-ritz-purple" />
                    <span>Itens descartáveis inclusos</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle2 className="w-4 h-4 text-ritz-purple" />
                    <span>Qualidade visual verificada</span>
                  </div>
                </div>
              </div>

              {/* Financial Info */}
              <div className="bg-ritz-purple text-white p-4 rounded-lg">
                <h3 className="text-lg font-bold mb-3">Informações Técnicas</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Custo Total:</span>
                    <span className="font-bold">R$ {totalCost.toFixed(2).replace('.', ',')}</span>
                  </div>
                  {suggestedPrice > 0 && (
                    <>
                      <div className="flex justify-between">
                        <span>Preço Sugerido:</span>
                        <span className="font-bold">R$ {suggestedPrice.toFixed(2).replace('.', ',')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Margem de Lucro:</span>
                        <span className="font-bold">{margin.toFixed(2).replace('.', ',')}%</span>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </CardContent>

            {/* Footer */}
            <div className="bg-ritz-yellow px-6 py-3 text-center text-sm font-semibold">
              Revisão: {new Date(product.updatedAt).toLocaleDateString('pt-BR')} | Ritz Sorvetes
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
