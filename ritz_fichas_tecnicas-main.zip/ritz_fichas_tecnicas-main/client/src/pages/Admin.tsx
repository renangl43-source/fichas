import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";
import { Loader2, ArrowLeft, Plus, Trash2, Edit, Save, X, Upload, Package } from "lucide-react";
import { toast } from "sonner";
import { useState, useRef } from "react";
import { getLoginUrl } from "@/const";

type IngredientForm = {
  name: string;
  quantity: string;
  unit: string;
  unitCost: string;
  order: number;
};

type PackagingForm = {
  name: string;
  quantity: string;
  unitCost: string;
  order: number;
};

type StepForm = {
  stepNumber: number;
  title: string;
  description: string;
};

export default function Admin() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: products, isLoading, refetch } = trpc.products.list.useQuery();
  const deleteMutation = trpc.products.delete.useMutation();
  const createMutation = trpc.products.create.useMutation();
  const updateMutation = trpc.products.update.useMutation();
  const uploadMutation = trpc.products.uploadImage.useMutation();
  const importExcelMutation = trpc.products.importExcel.useMutation();
  const utils = trpc.useUtils();
  
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingProductId, setEditingProductId] = useState<number | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const excelFileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    name: "",
    code: "",
    category: "",
    description: "",
    suggestedPrice: "",
    logoUrl: "",
    photoUrl: "",
    // Especificações Técnicas
    finalWeight: "",
    servingTemperature: "",
    productClassification: "",
    // Controle de Processo
    scoopType: "",
    // Segurança Alimentar
    foodSafetyNotes: "",
    // Padrão de Entrega
    deliveryStandards: "",
  });
  
  const [ingredients, setIngredients] = useState<IngredientForm[]>([]);
  const [packaging, setPackaging] = useState<PackagingForm[]>([]);
  const [steps, setSteps] = useState<StepForm[]>([]);
  const [ingredientSearchQuery, setIngredientSearchQuery] = useState<string>("");
  const [showIngredientSuggestions, setShowIngredientSuggestions] = useState<number | null>(null);
  
  const { data: baseIngredients } = trpc.baseIngredients.search.useQuery(
    { query: ingredientSearchQuery },
    { enabled: showIngredientSuggestions !== null }
  );
  
  const logoInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  // Check authentication and admin role
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    window.location.href = getLoginUrl();
    return null;
  }

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Acesso negado. Apenas administradores podem acessar esta página.</p>
            <Link href="/">
              <Button>Voltar para Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este produto?")) return;
    
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Produto excluído com sucesso!");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir produto");
    }
  };

  const handleEdit = async (id: number) => {
    try {
      // Fetch product with full details
      const product = await utils.products.getById.fetch({ id });
      if (!product) return;

      // Load product data into form
      setFormData({
        name: product.name,
        code: product.code,
        category: product.category,
        description: product.description || "",
        suggestedPrice: product.suggestedPrice || "",
        logoUrl: product.logoUrl || "",
        photoUrl: product.photoUrl || "",
        finalWeight: product.finalWeight || "",
        servingTemperature: product.servingTemperature || "",
        productClassification: product.productClassification || "",
        scoopType: product.scoopType || "",
        foodSafetyNotes: product.foodSafetyNotes || "",
        deliveryStandards: product.deliveryStandards || "",
      });

      // Load ingredients, packaging and steps
      setIngredients(product.ingredients?.map((ing: any) => ({
        name: ing.name,
        quantity: ing.quantity,
        unit: ing.unit,
        unitCost: ing.unitCost,
        order: ing.order,
      })) || []);

      setPackaging(product.packaging?.map((pkg: any) => ({
        name: pkg.name,
        quantity: pkg.quantity,
        unitCost: pkg.unitCost,
        order: pkg.order,
      })) || []);

      setSteps(product.steps?.map((step: any) => ({
        stepNumber: step.stepNumber,
        title: step.title,
        description: step.description,
      })) || []);

      setEditingProductId(id);
      setIsEditing(true);
    } catch (error: any) {
      toast.error(error.message || "Erro ao carregar produto");
    }
  };

  const handleImageUpload = async (file: File, type: 'logo' | 'photo') => {
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = reader.result as string;
        const result = await uploadMutation.mutateAsync({
          base64Data,
          filename: file.name,
          mimeType: file.type,
        });
        
        if (type === 'logo') {
          setFormData(prev => ({ ...prev, logoUrl: result.url }));
        } else {
          setFormData(prev => ({ ...prev, photoUrl: result.url }));
        }
        
        toast.success(`${type === 'logo' ? 'Logo' : 'Foto'} enviada com sucesso!`);
      };
      reader.readAsDataURL(file);
    } catch (error: any) {
      toast.error(error.message || "Erro ao fazer upload da imagem");
    }
  };

  const addIngredient = () => {
    setIngredients([...ingredients, { name: "", quantity: "", unit: "g", unitCost: "", order: ingredients.length }]);
  };

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const addPackaging = () => {
    setPackaging([...packaging, { name: "", quantity: "", unitCost: "", order: packaging.length }]);
  };

  const removePackaging = (index: number) => {
    setPackaging(packaging.filter((_, i) => i !== index));
  };

  const addStep = () => {
    setSteps([...steps, { stepNumber: steps.length + 1, title: "", description: "" }]);
  };

  const removeStep = (index: number) => {
    const newSteps = steps.filter((_, i) => i !== index);
    // Renumber steps
    setSteps(newSteps.map((step, i) => ({ ...step, stepNumber: i + 1 })));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name || !formData.code || !formData.category) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    try {
      // Filter out empty ingredients, packaging, and steps
      const validIngredients = ingredients.filter(ing => 
        ing.name.trim() !== '' && ing.quantity.trim() !== '' && ing.unitCost.trim() !== ''
      );
      const validPackaging = packaging.filter(pkg => 
        pkg.name.trim() !== '' && pkg.quantity.trim() !== '' && pkg.unitCost.trim() !== ''
      );
      const validSteps = steps.filter(step => 
        step.title.trim() !== '' && step.description.trim() !== ''
      );

      if (isEditing && editingProductId) {
        // Update existing product
        await updateMutation.mutateAsync({
          id: editingProductId,
          ...formData,
          ingredients: validIngredients,
          packaging: validPackaging,
          steps: validSteps,
        });
        toast.success("Produto atualizado com sucesso!");
        setIsEditing(false);
        setEditingProductId(null);
      } else {
        // Create new product
        await createMutation.mutateAsync({
          ...formData,
          ingredients: validIngredients,
          packaging: validPackaging,
          steps: validSteps,
        });
        toast.success("Produto criado com sucesso!");
        setIsCreating(false);
      }
      
      resetForm();
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar produto");
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      code: "",
      category: "",
      description: "",
      suggestedPrice: "",
      logoUrl: "",
      photoUrl: "",
      finalWeight: "",
      servingTemperature: "",
      productClassification: "",
      scoopType: "",
      foodSafetyNotes: "",
      deliveryStandards: "",
    });
    setIngredients([]);
    setPackaging([]);
    setSteps([]);
  };

  const calculateTotalCost = () => {
    const ingredientsCost = ingredients.reduce((sum, ing) => {
      const qty = parseFloat(ing.quantity) || 0;
      const cost = parseFloat(ing.unitCost) || 0;
      return sum + (qty * cost);
    }, 0);
    
    const packagingCost = packaging.reduce((sum, pkg) => {
      const qty = parseFloat(pkg.quantity) || 0;
      const cost = parseFloat(pkg.unitCost) || 0;
      return sum + (qty * cost);
    }, 0);
    
    return {
      ingredientsCost,
      packagingCost,
      totalCost: ingredientsCost + packagingCost
    };
  };

  const calculateMargin = () => {
    const { totalCost } = calculateTotalCost();
    const price = parseFloat(formData.suggestedPrice) || 0;
    if (price === 0) return 0;
    return ((price - totalCost) / price) * 100;
  };

  const handleExcelImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validar tipo de arquivo
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      toast.error('Por favor, selecione um arquivo Excel (.xlsx ou .xls)');
      return;
    }

    setIsImporting(true);

    try {
      // Converter arquivo para base64
      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          const base64 = event.target?.result as string;
          const base64Data = base64.split(',')[1]; // Remover prefixo data:application/...

          // Enviar para o backend
          const result = await importExcelMutation.mutateAsync({
            fileBase64: base64Data,
          });

          toast.success(result.message || 'Produto importado com sucesso!');
          refetch();
          
          // Limpar input
          if (excelFileInputRef.current) {
            excelFileInputRef.current.value = '';
          }
        } catch (error: any) {
          console.error('Erro ao importar:', error);
          toast.error(error.message || 'Erro ao importar planilha');
        } finally {
          setIsImporting(false);
        }
      };

      reader.onerror = () => {
        toast.error('Erro ao ler arquivo');
        setIsImporting(false);
      };

      reader.readAsDataURL(file);
    } catch (error: any) {
      toast.error(error.message || 'Erro ao processar arquivo');
      setIsImporting(false);
    }
  };

  if (isCreating || isEditing) {
    return (
      <div className="min-h-screen bg-background">
        <header className="bg-ritz-purple text-white shadow-lg">
          <div className="container py-4">
            <div className="flex items-center justify-between">
              <Button variant="secondary" size="sm" onClick={() => { setIsCreating(false); setIsEditing(false); setEditingProductId(null); resetForm(); }}>
                <X className="w-4 h-4 mr-2" />
                Cancelar
              </Button>
              <h1 className="text-xl font-bold">{isEditing ? "Editar Produto" : "Novo Produto"}</h1>
              <Button variant="secondary" size="sm" onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending}>
                {(createMutation.isPending || updateMutation.isPending) ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                Salvar
              </Button>
            </div>
          </div>
        </header>

        <main className="container py-8">
          <form onSubmit={handleSubmit} className="max-w-4xl mx-auto space-y-6">
            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle>Informações Básicas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nome do Produto *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="code">Código *</Label>
                    <Input
                      id="code"
                      value={formData.code}
                      onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Categoria *</Label>
                    <Input
                      id="category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      placeholder="Ex: Açaís, Sorvetes, Picolés"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="suggestedPrice">Preço Sugerido (R$)</Label>
                    <Input
                      id="suggestedPrice"
                      type="number"
                      step="0.01"
                      value={formData.suggestedPrice}
                      onChange={(e) => setFormData({ ...formData, suggestedPrice: e.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Images */}
            <Card>
              <CardHeader>
                <CardTitle>Imagens</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Logo</Label>
                    <div className="mt-2">
                      <input
                        ref={logoInputRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleImageUpload(file, 'logo');
                        }}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => logoInputRef.current?.click()}
                        disabled={uploadMutation.isPending}
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Enviar Logo
                      </Button>
                      {formData.logoUrl && (
                        <div className="mt-2">
                          <img src={formData.logoUrl} alt="Logo preview" className="w-32 h-32 object-contain border rounded" />
                        </div>
                      )}
                    </div>
                  </div>
                  <div>
                    <Label>Foto do Produto</Label>
                    <div className="mt-2">
                      <input
                        ref={photoInputRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleImageUpload(file, 'photo');
                        }}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => photoInputRef.current?.click()}
                        disabled={uploadMutation.isPending}
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Enviar Foto
                      </Button>
                      {formData.photoUrl && (
                        <div className="mt-2">
                          <img src={formData.photoUrl} alt="Photo preview" className="w-32 h-32 object-contain border rounded" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Especificações Técnicas */}
            <Card>
              <CardHeader>
                <CardTitle>Especificações Técnicas</CardTitle>
                <CardDescription>Informações técnicas para padronização entre franquias</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Peso Final Padrão</Label>
                    <Input
                      value={formData.finalWeight}
                      onChange={(e) => setFormData({ ...formData, finalWeight: e.target.value })}
                      placeholder="Ex: 350g"
                    />
                  </div>
                  <div>
                    <Label>Temperatura de Serviço</Label>
                    <Input
                      value={formData.servingTemperature}
                      onChange={(e) => setFormData({ ...formData, servingTemperature: e.target.value })}
                      placeholder="Ex: -10ºC a -12ºC"
                    />
                  </div>
                  <div>
                    <Label>Classificação do Produto</Label>
                    <Input
                      value={formData.productClassification}
                      onChange={(e) => setFormData({ ...formData, productClassification: e.target.value })}
                      placeholder="Ex: sobremesa gelada composta"
                    />
                  </div>
                  <div>
                    <Label>Tipo de Colher Dosadora</Label>
                    <Input
                      value={formData.scoopType}
                      onChange={(e) => setFormData({ ...formData, scoopType: e.target.value })}
                      placeholder="Ex: 50ml ou Código Ritz #3"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Segurança Alimentar */}
            <Card>
              <CardHeader>
                <CardTitle>Segurança Alimentar</CardTitle>
                <CardDescription>Normas obrigatórias de segurança e manipulação</CardDescription>
              </CardHeader>
              <CardContent>
                <Label>Normas de Segurança</Label>
                <Textarea
                  value={formData.foodSafetyNotes}
                  onChange={(e) => setFormData({ ...formData, foodSafetyNotes: e.target.value })}
                  placeholder="Ex:\n• Manipular com luvas descartáveis\n• Produto mantido sob congelamento constante\n• Não recongelar após exposição\n• Higienização do boleador a cada montagem\n• Validade dos adicionais após abertura"
                  rows={6}
                  className="resize-none"
                />
              </CardContent>
            </Card>

            {/* Padrão de Entrega */}
            <Card>
              <CardHeader>
                <CardTitle>Padrão de Entrega ao Cliente</CardTitle>
                <CardDescription>Orientações para entrega e serviço</CardDescription>
              </CardHeader>
              <CardContent>
                <Label>Orientações de Entrega</Label>
                <Textarea
                  value={formData.deliveryStandards}
                  onChange={(e) => setFormData({ ...formData, deliveryStandards: e.target.value })}
                  placeholder="Ex:\n• Produto servido imediatamente após montagem\n• Não transportar sem tampa vedada\n• Orientar consumo imediato\n• Não recomendado para delivery longo (>15 min)"
                  rows={5}
                  className="resize-none"
                />
              </CardContent>
            </Card>

            {/* Ingredients */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Ingredientes</CardTitle>
                  <Button type="button" size="sm" onClick={addIngredient}>
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {ingredients.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Nenhum ingrediente adicionado</p>
                ) : (
                  <div className="space-y-3">
                    {ingredients.map((ing, index) => (
                      <div key={index} className="flex gap-2 items-end">
                        <div className="flex-1 relative">
                          <Label className="text-xs">Nome</Label>
                          <Input
                            value={ing.name}
                            onChange={(e) => {
                              const newIng = [...ingredients];
                              newIng[index].name = e.target.value;
                              setIngredients(newIng);
                              setIngredientSearchQuery(e.target.value);
                              setShowIngredientSuggestions(index);
                            }}
                            onFocus={() => {
                              setIngredientSearchQuery(ing.name);
                              setShowIngredientSuggestions(index);
                            }}
                            onBlur={() => {
                              setTimeout(() => setShowIngredientSuggestions(null), 200);
                            }}
                            placeholder="Ex: Açaí Ritz"
                          />
                          {showIngredientSuggestions === index && baseIngredients && baseIngredients.length > 0 && (
                            <div className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-auto">
                              {baseIngredients.map((baseIng: any) => (
                                <button
                                  key={baseIng.id}
                                  type="button"
                                  className="w-full px-3 py-2 text-left hover:bg-purple-50 flex justify-between items-center text-sm"
                                  onClick={() => {
                                    const newIng = [...ingredients];
                                    newIng[index].name = baseIng.name;
                                    newIng[index].unit = baseIng.usageUnit;
                                    newIng[index].unitCost = (baseIng.unitCost / 100).toFixed(4);
                                    setIngredients(newIng);
                                    setShowIngredientSuggestions(null);
                                  }}
                                >
                                  <span className="font-medium">{baseIng.name}</span>
                                  <span className="text-xs text-gray-500">
                                    R$ {(baseIng.unitCost / 100).toFixed(4)}/{baseIng.usageUnit}
                                  </span>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="w-24">
                          <Label className="text-xs">Qtd</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={ing.quantity}
                            onChange={(e) => {
                              const newIng = [...ingredients];
                              newIng[index].quantity = e.target.value;
                              setIngredients(newIng);
                            }}
                          />
                        </div>
                        <div className="w-20">
                          <Label className="text-xs">Un.</Label>
                          <Input
                            value={ing.unit}
                            onChange={(e) => {
                              const newIng = [...ingredients];
                              newIng[index].unit = e.target.value;
                              setIngredients(newIng);
                            }}
                            placeholder="g, ml"
                          />
                        </div>
                        <div className="w-28">
                          <Label className="text-xs">Custo/Un.</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={ing.unitCost}
                            onChange={(e) => {
                              const newIng = [...ingredients];
                              newIng[index].unitCost = e.target.value;
                              setIngredients(newIng);
                            }}
                          />
                        </div>
                        <Button type="button" variant="destructive" size="sm" onClick={() => removeIngredient(index)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Packaging */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Embalagens</CardTitle>
                  <Button type="button" size="sm" onClick={addPackaging}>
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {packaging.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Nenhuma embalagem adicionada</p>
                ) : (
                  <div className="space-y-3">
                    {packaging.map((pkg, index) => (
                      <div key={index} className="flex gap-2 items-end">
                        <div className="flex-1">
                          <Label className="text-xs">Nome</Label>
                          <Input
                            value={pkg.name}
                            onChange={(e) => {
                              const newPkg = [...packaging];
                              newPkg[index].name = e.target.value;
                              setPackaging(newPkg);
                            }}
                            placeholder="Ex: Copo 500ml"
                          />
                        </div>
                        <div className="w-24">
                          <Label className="text-xs">Qtd</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={pkg.quantity}
                            onChange={(e) => {
                              const newPkg = [...packaging];
                              newPkg[index].quantity = e.target.value;
                              setPackaging(newPkg);
                            }}
                          />
                        </div>
                        <div className="w-28">
                          <Label className="text-xs">Custo/Un.</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={pkg.unitCost}
                            onChange={(e) => {
                              const newPkg = [...packaging];
                              newPkg[index].unitCost = e.target.value;
                              setPackaging(newPkg);
                            }}
                          />
                        </div>
                        <Button type="button" variant="destructive" size="sm" onClick={() => removePackaging(index)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Steps */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Passos de Preparo</CardTitle>
                  <Button type="button" size="sm" onClick={addStep}>
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {steps.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">Nenhum passo adicionado</p>
                ) : (
                  <div className="space-y-4">
                    {steps.map((step, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-semibold">Passo {step.stepNumber}</span>
                          <Button type="button" variant="destructive" size="sm" onClick={() => removeStep(index)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="space-y-2">
                          <div>
                            <Label className="text-xs">Título</Label>
                            <Input
                              value={step.title}
                              onChange={(e) => {
                                const newSteps = [...steps];
                                newSteps[index].title = e.target.value;
                                setSteps(newSteps);
                              }}
                              placeholder="Ex: BASE - PRIMEIRA CAMADA"
                            />
                          </div>
                          <div>
                            <Label className="text-xs">Descrição</Label>
                            <Textarea
                              value={step.description}
                              onChange={(e) => {
                                const newSteps = [...steps];
                                newSteps[index].description = e.target.value;
                                setSteps(newSteps);
                              }}
                              rows={2}
                              placeholder="Descreva o passo em detalhes..."
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Cost Summary */}
            <Card className="bg-gradient-to-br from-purple-50 to-yellow-50 border-2 border-ritz-purple shadow-lg">
              <CardHeader className="bg-ritz-purple text-white">
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">📊</span>
                  Resumo de Custos em Tempo Real
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {/* Breakdown de custos */}
                  <div className="space-y-2 pb-4 border-b border-gray-300">
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Custo dos Ingredientes:</span>
                      <span className="font-medium">R$ {calculateTotalCost().ingredientsCost.toFixed(2).replace('.', ',')}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Custo das Embalagens:</span>
                      <span className="font-medium">R$ {calculateTotalCost().packagingCost.toFixed(2).replace('.', ',')}</span>
                    </div>
                  </div>
                  
                  {/* Custo Total Destacado */}
                  <div className="flex justify-between items-center bg-white rounded-lg p-4 shadow-md">
                    <span className="text-lg font-bold text-ritz-purple">Custo Total:</span>
                    <span className="text-2xl font-bold text-ritz-purple">R$ {calculateTotalCost().totalCost.toFixed(2).replace('.', ',')}</span>
                  </div>
                  
                  {formData.suggestedPrice && (
                    <>
                      <div className="flex justify-between items-center bg-white rounded-lg p-4 shadow-md">
                        <span className="text-lg font-bold text-gray-700">Preço Sugerido:</span>
                        <span className="text-2xl font-bold text-green-600">R$ {parseFloat(formData.suggestedPrice).toFixed(2).replace('.', ',')}</span>
                      </div>
                      <div className="flex justify-between items-center bg-gradient-to-r from-green-100 to-green-50 rounded-lg p-4 shadow-md border-2 border-green-400">
                        <span className="text-lg font-bold text-green-700">Margem de Lucro:</span>
                        <span className="text-2xl font-bold text-green-700">{calculateMargin().toFixed(2).replace('.', ',')}%</span>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </form>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-ritz-purple text-white shadow-lg">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="secondary" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Painel Administrativo</h1>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => excelFileInputRef.current?.click()} disabled={isImporting}>
                {isImporting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Upload className="w-4 h-4 mr-2" />
                )}
                Importar Excel
              </Button>
              <input
                ref={excelFileInputRef}
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={handleExcelImport}
              />
              <Button variant="outline" size="sm" onClick={() => setLocation("/base-ingredients")} className="border-ritz-yellow text-white hover:bg-white/10">
                <Package className="w-4 h-4 mr-2" />
                Ingredientes Base
              </Button>
              <Button variant="secondary" size="sm" onClick={() => setIsCreating(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Novo Produto
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container py-8">
        <Card>
          <CardHeader>
            <CardTitle>Produtos Cadastrados</CardTitle>
            <CardDescription>Gerencie os produtos e suas fichas técnicas</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : !products || products.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">Nenhum produto cadastrado ainda.</p>
                <Button onClick={() => setIsCreating(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Cadastrar Primeiro Produto
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                {products.map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50">
                    <div className="flex items-center gap-4">
                      {product.photoUrl && (
                        <img src={product.photoUrl} alt={product.name} className="w-16 h-16 object-contain rounded" />
                      )}
                      <div>
                        <h3 className="font-semibold">{product.name}</h3>
                        <p className="text-sm text-muted-foreground">Código: {product.code} | {product.category}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Link href={`/product/${product.id}`}>
                        <Button variant="outline" size="sm">
                          Ver Ficha
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(product.id)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(product.id)}
                        disabled={deleteMutation.isPending}
                      >
                        {deleteMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
