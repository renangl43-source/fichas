import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Pencil, Trash2, Plus, ArrowLeft, Package } from "lucide-react";

export default function BaseIngredients() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: ingredients, isLoading, refetch } = trpc.baseIngredients.list.useQuery();
  const createMutation = trpc.baseIngredients.create.useMutation();
  const updateMutation = trpc.baseIngredients.update.useMutation();
  const deleteMutation = trpc.baseIngredients.delete.useMutation();

  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    purchaseUnit: "",
    purchaseQuantity: "",
    purchasePrice: "",
    usageUnit: "",
  });

  // Redirect if not authenticated or not admin
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-ritz-purple"></div>
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    setLocation("/");
    return null;
  }

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este ingrediente?")) return;

    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Ingrediente excluído com sucesso!");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao excluir ingrediente");
    }
  };

  const handleEdit = (ingredient: any) => {
    setEditingId(ingredient.id);
    setIsEditing(true);
    setFormData({
      name: ingredient.name,
      purchaseUnit: ingredient.purchaseUnit,
      purchaseQuantity: ingredient.purchaseQuantity.toString(),
      purchasePrice: (ingredient.purchasePrice / 100).toFixed(2),
      usageUnit: ingredient.usageUnit,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const data = {
        name: formData.name,
        purchaseUnit: formData.purchaseUnit,
        purchaseQuantity: parseInt(formData.purchaseQuantity),
        purchasePrice: Math.round(parseFloat(formData.purchasePrice) * 100),
        usageUnit: formData.usageUnit,
      };

      if (isEditing && editingId) {
        await updateMutation.mutateAsync({ id: editingId, ...data });
        toast.success("Ingrediente atualizado com sucesso!");
      } else {
        await createMutation.mutateAsync(data);
        toast.success("Ingrediente cadastrado com sucesso!");
      }

      // Reset form
      setFormData({
        name: "",
        purchaseUnit: "",
        purchaseQuantity: "",
        purchasePrice: "",
        usageUnit: "",
      });
      setIsCreating(false);
      setIsEditing(false);
      setEditingId(null);
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Erro ao salvar ingrediente");
    }
  };

  const formatCurrency = (cents: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(cents / 100);
  };

  const getConversionFactor = (purchaseUnit: string, usageUnit: string): number => {
    const normalizedPurchase = purchaseUnit.toLowerCase().trim();
    const normalizedUsage = usageUnit.toLowerCase().trim();

    if (normalizedPurchase === 'kg' && normalizedUsage === 'g') return 1000;
    if (normalizedPurchase === 'kg' && normalizedUsage === 'kg') return 1;
    if (normalizedPurchase === 'g' && normalizedUsage === 'g') return 1;
    if (normalizedPurchase === 'g' && normalizedUsage === 'kg') return 0.001;

    if (normalizedPurchase === 'l' && normalizedUsage === 'ml') return 1000;
    if (normalizedPurchase === 'l' && normalizedUsage === 'l') return 1;
    if (normalizedPurchase === 'ml' && normalizedUsage === 'ml') return 1;
    if (normalizedPurchase === 'ml' && normalizedUsage === 'l') return 0.001;

    return 1;
  };

  const calculateUnitCost = (): number => {
    if (!formData.purchaseQuantity || !formData.purchasePrice || !formData.purchaseUnit || !formData.usageUnit) {
      return 0;
    }

    const quantity = parseInt(formData.purchaseQuantity);
    const price = parseFloat(formData.purchasePrice);
    const conversionFactor = getConversionFactor(formData.purchaseUnit, formData.usageUnit);

    const totalUnits = quantity * conversionFactor;
    const unitCostInReais = price / totalUnits;
    
    return Math.round(unitCostInReais * 100);
  };

  if (isCreating || isEditing) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-2xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => {
              setIsCreating(false);
              setIsEditing(false);
              setEditingId(null);
              setFormData({
                name: "",
                purchaseUnit: "",
                purchaseQuantity: "",
                purchasePrice: "",
                usageUnit: "",
              });
            }}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>

          <Card>
            <CardHeader>
              <CardTitle>{isEditing ? "Editar" : "Novo"} Ingrediente Base</CardTitle>
              <CardDescription>
                {isEditing ? "Atualize" : "Cadastre"} um ingrediente com preço de compra para usar nas fichas técnicas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Nome do Ingrediente *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: Açaí"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="purchaseUnit">Unidade de Compra *</Label>
                    <Input
                      id="purchaseUnit"
                      value={formData.purchaseUnit}
                      onChange={(e) => setFormData({ ...formData, purchaseUnit: e.target.value })}
                      placeholder="Ex: caixa, kg"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="purchaseQuantity">Quantidade na Unidade *</Label>
                    <Input
                      id="purchaseQuantity"
                      type="number"
                      value={formData.purchaseQuantity}
                      onChange={(e) => setFormData({ ...formData, purchaseQuantity: e.target.value })}
                      placeholder="Ex: 10"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="purchasePrice">Preço de Compra (R$) *</Label>
                  <Input
                    id="purchasePrice"
                    type="number"
                    step="0.01"
                    value={formData.purchasePrice}
                    onChange={(e) => setFormData({ ...formData, purchasePrice: e.target.value })}
                    placeholder="Ex: 160.00"
                    required
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Preço total da unidade de compra
                  </p>
                </div>

                <div>
                  <Label htmlFor="usageUnit">Unidade de Uso nas Fichas *</Label>
                  <Input
                    id="usageUnit"
                    value={formData.usageUnit}
                    onChange={(e) => setFormData({ ...formData, usageUnit: e.target.value })}
                    placeholder="Ex: g, ml"
                    required
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Unidade que será usada nas fichas técnicas
                  </p>
                </div>

                {formData.purchaseQuantity && formData.purchasePrice && formData.purchaseUnit && formData.usageUnit && (
                  <div className="bg-ritz-yellow/10 border border-ritz-yellow p-4 rounded-lg">
                    <p className="text-sm font-medium">Custo Unitário Calculado:</p>
                    <p className="text-2xl font-bold text-ritz-purple">
                      {formatCurrency(calculateUnitCost())}/{formData.usageUnit}
                    </p>
                    <p className="text-xs text-gray-600 mt-2">
                      Cálculo: R$ {parseFloat(formData.purchasePrice).toFixed(2)} ÷ ({formData.purchaseQuantity} {formData.purchaseUnit} × {getConversionFactor(formData.purchaseUnit, formData.usageUnit)})
                    </p>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button type="submit" className="flex-1">
                    {isEditing ? "Atualizar" : "Cadastrar"} Ingrediente
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsCreating(false);
                      setIsEditing(false);
                      setEditingId(null);
                      setFormData({
                        name: "",
                        purchaseUnit: "",
                        purchaseQuantity: "",
                        purchasePrice: "",
                        usageUnit: "",
                      });
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-ritz-purple text-white p-6 shadow-lg">
        <div className="container mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Ingredientes Base</h1>
            <p className="text-ritz-yellow mt-1">Gestão de preços de ingredientes</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              onClick={() => setLocation("/admin")}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar ao Painel
            </Button>
            <Button
              onClick={() => setIsCreating(true)}
              className="bg-ritz-yellow text-ritz-purple hover:bg-ritz-yellow/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Ingrediente
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto p-8">
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-ritz-purple"></div>
          </div>
        ) : ingredients && ingredients.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ingredients.map((ingredient) => (
              <Card key={ingredient.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <Package className="w-5 h-5 text-ritz-purple" />
                      <CardTitle className="text-lg">{ingredient.name}</CardTitle>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleEdit(ingredient)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(ingredient.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Compra:</span>
                    <span className="font-medium">
                      {ingredient.purchaseQuantity} {ingredient.purchaseUnit}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Preço:</span>
                    <span className="font-medium">{formatCurrency(ingredient.purchasePrice)}</span>
                  </div>
                  <div className="border-t pt-2 mt-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Custo por {ingredient.usageUnit}:</span>
                      <span className="text-lg font-bold text-ritz-purple">
                        {formatCurrency(ingredient.unitCost)}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Package className="w-16 h-16 text-gray-300 mb-4" />
              <p className="text-gray-500 text-lg mb-4">Nenhum ingrediente cadastrado</p>
              <Button onClick={() => setIsCreating(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Cadastrar Primeiro Ingrediente
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
