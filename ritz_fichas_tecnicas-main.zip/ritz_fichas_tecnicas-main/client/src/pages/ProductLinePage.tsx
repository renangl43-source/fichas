import { useParams, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ComparisonTable } from "@/components/ComparisonTable";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function ProductLinePage() {
  const { productLine } = useParams<{ productLine: string }>();
  const { data, isLoading, error } = trpc.products.getUnified.useQuery(
    { productLine: productLine! },
    { enabled: !!productLine }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-8">
        <div className="max-w-4xl mx-auto">
          <Link href="/">
            <Button variant="ghost" className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
          <Card className="border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <p className="text-red-600">Linha de produto não encontrada</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const { products, steps } = data;

  // Encontrar produtos por tamanho
  const product300ml = products.find(p => p.size === '300ml');
  const product500ml = products.find(p => p.size === '500ml');
  const product700ml = products.find(p => p.size === '700ml');

  // Criar mapa de ingredientes por nome
  const ingredientMap = new Map<string, { name: string; size300ml: string; size500ml: string; size700ml: string }>();
  
  products.forEach(product => {
    product.ingredients.forEach(ing => {
      if (!ingredientMap.has(ing.name)) {
        ingredientMap.set(ing.name, {
          name: ing.name,
          size300ml: '-',
          size500ml: '-',
          size700ml: '-',
        });
      }
      
      const entry = ingredientMap.get(ing.name)!;
      const quantityStr = `${parseFloat(ing.quantity).toFixed(2).replace('.', ',')} ${ing.unit}`;
      
      if (product.size === '300ml') entry.size300ml = quantityStr;
      else if (product.size === '500ml') entry.size500ml = quantityStr;
      else if (product.size === '700ml') entry.size700ml = quantityStr;
    });
  });

  // Criar mapa de embalagens por nome
  const packagingMap = new Map<string, { name: string; size300ml: string; size500ml: string; size700ml: string }>();
  
  products.forEach(product => {
    product.packaging.forEach(pkg => {
      if (!packagingMap.has(pkg.name)) {
        packagingMap.set(pkg.name, {
          name: pkg.name,
          size300ml: '-',
          size500ml: '-',
          size700ml: '-',
        });
      }
      
      const entry = packagingMap.get(pkg.name)!;
      const quantityStr = parseFloat(pkg.quantity).toFixed(2).replace('.', ',');
      
      if (product.size === '300ml') entry.size300ml = quantityStr;
      else if (product.size === '500ml') entry.size500ml = quantityStr;
      else if (product.size === '700ml') entry.size700ml = quantityStr;
    });
  });

  const ingredientRows = Array.from(ingredientMap.values());
  const packagingRows = Array.from(packagingMap.values());

  // Nome da linha de produto (pegar do primeiro produto)
  const productName = products[0]?.name.replace(/ (300ml|500ml|700ml)$/i, '') || '';

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-8 shadow-lg">
        <div className="container mx-auto px-4">
          <Link href="/">
            <Button variant="ghost" className="mb-4 text-white hover:bg-white/20">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </Link>
          <h1 className="text-4xl font-bold">{productName}</h1>
          <p className="text-purple-100 mt-2">Ficha Técnica Unificada - Comparação de Tamanhos</p>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Fotos dos Produtos */}
        {products.some(p => p.photoUrl) && (
          <Card>
            <CardHeader>
              <CardTitle className="text-purple-700">Produtos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[product300ml, product500ml, product700ml].filter(Boolean).map((product) => (
                  <div key={product!.id} className="text-center space-y-2">
                    {product!.photoUrl && (
                      <img
                        src={product!.photoUrl}
                        alt={product!.name}
                        className="w-full h-48 object-contain rounded-lg bg-white"
                      />
                    )}
                    <p className="font-semibold text-purple-900">{product!.size}</p>
                    <p className="text-sm text-gray-600">Código: {product!.code}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Descrição */}
        {products[0]?.description && (
          <Card>
            <CardHeader>
              <CardTitle className="text-purple-700">Descrição</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">{products[0].description}</p>
            </CardContent>
          </Card>
        )}

        {/* Tabela de Ingredientes */}
        {ingredientRows.length > 0 && (
          <Card>
            <CardContent className="pt-6">
              <ComparisonTable
                title="Ingredientes"
                rows={ingredientRows}
              />
            </CardContent>
          </Card>
        )}

        {/* Tabela de Embalagens */}
        {packagingRows.length > 0 && (
          <Card>
            <CardContent className="pt-6">
              <ComparisonTable
                title="Embalagens"
                rows={packagingRows}
              />
            </CardContent>
          </Card>
        )}

        {/* Passo a Passo de Montagem */}
        {steps.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-purple-700">Passo a Passo de Montagem</CardTitle>
              <p className="text-sm text-gray-600">Válido para todos os tamanhos</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {steps.map((step) => (
                  <div key={step.stepNumber} className="flex gap-4 p-4 bg-purple-50 rounded-lg">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold">
                      {step.stepNumber}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-purple-900 mb-1">{step.title}</h3>
                      <p className="text-gray-700 text-sm leading-relaxed">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Links para Fichas Individuais */}
        <Card>
          <CardHeader>
            <CardTitle className="text-purple-700">Fichas Técnicas Individuais</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {products.map((product) => (
                <Link key={product.id} href={`/product/${product.id}`}>
                  <Button variant="outline" className="w-full">
                    Ver Ficha {product.size}
                  </Button>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
