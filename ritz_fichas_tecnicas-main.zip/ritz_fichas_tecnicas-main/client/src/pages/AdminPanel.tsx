import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Package, Database, ArrowLeft } from "lucide-react";

export default function AdminPanel() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-yellow-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-yellow-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle className="text-2xl text-purple-700">Acesso Restrito</CardTitle>
            <CardDescription>
              Você precisa estar autenticado para acessar o painel administrativo.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={() => setLocation("/")} 
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              Voltar para Página Inicial
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-yellow-50">
      {/* Header */}
      <header className="bg-purple-700 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Painel Administrativo</h1>
              <p className="text-purple-200 mt-1">Sistema de Fichas Técnicas - Ritz Sorvetes</p>
            </div>
            <Button
              variant="outline"
              onClick={() => setLocation("/")}
              className="bg-white text-purple-700 hover:bg-purple-50"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar ao Site
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Olá, {user.name}!
          </h2>
          <p className="text-gray-600">
            Escolha uma das opções abaixo para gerenciar o sistema de fichas técnicas.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-4xl">
          {/* Card de Produtos */}
          <Card className="hover:shadow-xl transition-shadow cursor-pointer border-2 hover:border-purple-300">
            <CardHeader className="bg-gradient-to-br from-purple-50 to-purple-100">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-purple-600 rounded-lg">
                  <Package className="h-6 w-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-xl text-purple-700">
                    Gerenciar Produtos
                  </CardTitle>
                  <CardDescription>
                    Criar, editar e excluir fichas técnicas
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-gray-600 mb-4">
                Gerencie todos os produtos, ingredientes, embalagens e passos de preparo das fichas técnicas.
              </p>
              <Button
                onClick={() => setLocation("/admin/products")}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                Acessar Gestão de Produtos
              </Button>
            </CardContent>
          </Card>

          {/* Card de Ingredientes Base */}
          <Card className="hover:shadow-xl transition-shadow cursor-pointer border-2 hover:border-yellow-300">
            <CardHeader className="bg-gradient-to-br from-yellow-50 to-yellow-100">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-yellow-500 rounded-lg">
                  <Database className="h-6 w-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-xl text-yellow-700">
                    Ingredientes Base
                  </CardTitle>
                  <CardDescription>
                    Gerenciar preços e custos base
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <p className="text-gray-600 mb-4">
                Configure os preços de compra e custos unitários dos ingredientes utilizados nas fichas técnicas.
              </p>
              <Button
                onClick={() => setLocation("/base-ingredients")}
                className="w-full bg-yellow-500 hover:bg-yellow-600"
              >
                Acessar Ingredientes Base
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Informações do Usuário */}
        <Card className="mt-8 max-w-4xl">
          <CardHeader>
            <CardTitle className="text-lg">Informações da Sessão</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-semibold text-gray-700">Nome:</span>
                <span className="ml-2 text-gray-600">{user.name}</span>
              </div>
              <div>
                <span className="font-semibold text-gray-700">Email:</span>
                <span className="ml-2 text-gray-600">{user.email || "Não informado"}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
