import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Download, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

export function DownloadAllButton() {
  const [isDownloading, setIsDownloading] = useState(false);

  const exportAllMutation = trpc.products.exportAllPDFAttendant.useMutation();

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      const result = await exportAllMutation.mutateAsync();
      
      // Convert base64 to blob
      const binaryString = window.atob(result.pdfBase64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: 'application/pdf' });
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = result.filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      alert(`Download concluído! ${result.productCount} fichas técnicas foram baixadas.`);
    } catch (error) {
      console.error('Erro ao baixar fichas:', error);
      alert('Erro ao baixar: Não foi possível gerar o PDF. Tente novamente.');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <Button
      onClick={handleDownload}
      disabled={isDownloading}
      size="lg"
      className="bg-ritz-purple hover:bg-ritz-purple/90"
    >
      {isDownloading ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Gerando PDF...
        </>
      ) : (
        <>
          <Download className="w-4 h-4 mr-2" />
          Baixar Todas as Fichas (PDF Atendente)
        </>
      )}
    </Button>
  );
}
