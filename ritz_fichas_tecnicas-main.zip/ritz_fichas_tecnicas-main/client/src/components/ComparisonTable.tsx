import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

interface ComparisonTableProps {
  title: string;
  rows: Array<{
    name: string;
    size300ml: string;
    size500ml: string;
    size700ml: string;
  }>;
  showCosts?: boolean;
}

export function ComparisonTable({ title, rows, showCosts = false }: ComparisonTableProps) {
  if (rows.length === 0) return null;

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-purple-700">{title}</h2>
      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-purple-50">
              <TableHead className="font-bold text-purple-900 w-[40%]">
                {title === "Ingredientes" ? "Ingrediente" : title === "Embalagens" ? "Item" : "Item"}
              </TableHead>
              <TableHead className="font-bold text-purple-900 text-center">300ml</TableHead>
              <TableHead className="font-bold text-purple-900 text-center">500ml</TableHead>
              <TableHead className="font-bold text-purple-900 text-center">700ml</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row, index) => (
              <TableRow key={index} className="hover:bg-purple-50/50">
                <TableCell className="font-medium">{row.name}</TableCell>
                <TableCell className="text-center">{row.size300ml}</TableCell>
                <TableCell className="text-center">{row.size500ml}</TableCell>
                <TableCell className="text-center">{row.size700ml}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
