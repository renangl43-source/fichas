import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export interface ProductFiltersState {
  search: string;
  category: string;
  size: string;
  baseType: string;
  sortBy: string;
}

interface ProductFiltersProps {
  filters: ProductFiltersState;
  onFiltersChange: (filters: ProductFiltersState) => void;
  resultCount: number;
}

export function ProductFilters({
  filters,
  onFiltersChange,
  resultCount,
}: ProductFiltersProps) {
  const handleSearchChange = (value: string) => {
    onFiltersChange({ ...filters, search: value });
  };

  const handleCategoryChange = (value: string) => {
    onFiltersChange({ ...filters, category: value });
  };

  const handleSizeChange = (value: string) => {
    onFiltersChange({ ...filters, size: value });
  };

  const handleBaseTypeChange = (value: string) => {
    onFiltersChange({ ...filters, baseType: value });
  };

  const handleSortChange = (value: string) => {
    onFiltersChange({ ...filters, sortBy: value });
  };

  const handleClearFilters = () => {
    onFiltersChange({
      search: "",
      category: "all",
      size: "all",
      baseType: "all",
      sortBy: "name-asc",
    });
  };

  const hasActiveFilters =
    filters.search ||
    filters.category !== "all" ||
    filters.size !== "all" ||
    filters.baseType !== "all" ||
    filters.sortBy !== "name-asc";

  return (
    <div className="space-y-4 mb-8">
      {/* Barra de busca */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Buscar por nome, código ou ingredientes..."
          value={filters.search}
          onChange={(e) => handleSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Filtros e ordenação */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Select value={filters.category} onValueChange={handleCategoryChange}>
          <SelectTrigger>
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas categorias</SelectItem>
            <SelectItem value="acais">Açaís</SelectItem>
            <SelectItem value="cozinha">Cozinha</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filters.size} onValueChange={handleSizeChange}>
          <SelectTrigger>
            <SelectValue placeholder="Tamanho" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos tamanhos</SelectItem>
            <SelectItem value="300">300ml</SelectItem>
            <SelectItem value="500">500ml</SelectItem>
            <SelectItem value="700">700ml</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filters.baseType} onValueChange={handleBaseTypeChange}>
          <SelectTrigger>
            <SelectValue placeholder="Tipo de base" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos tipos</SelectItem>
            <SelectItem value="acai">Base de Açaí</SelectItem>
            <SelectItem value="sorvete">Base de Sorvete</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filters.sortBy} onValueChange={handleSortChange}>
          <SelectTrigger>
            <SelectValue placeholder="Ordenar por" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name-asc">Nome (A-Z)</SelectItem>
            <SelectItem value="name-desc">Nome (Z-A)</SelectItem>
            <SelectItem value="price-asc">Preço (menor)</SelectItem>
            <SelectItem value="price-desc">Preço (maior)</SelectItem>
            <SelectItem value="code-asc">Código</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Contador de resultados e botão limpar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-sm">
            {resultCount} {resultCount === 1 ? "produto encontrado" : "produtos encontrados"}
          </Badge>
          {hasActiveFilters && (
            <span className="text-sm text-muted-foreground">
              (filtros ativos)
            </span>
          )}
        </div>

        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClearFilters}
            className="gap-2"
          >
            <X className="h-4 w-4" />
            Limpar filtros
          </Button>
        )}
      </div>
    </div>
  );
}
