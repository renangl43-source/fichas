import Database from 'better-sqlite3';

const db = new Database('./local.db');

// Buscar todos os produtos
const products = db.prepare('SELECT id, code, name FROM products ORDER BY code').all();

console.log('=== AUDITORIA DE PASSOS DE MONTAGEM ===\n');
console.log(`Total de produtos: ${products.length}\n`);

let withSteps = 0;
let withoutSteps = 0;

products.forEach(product => {
  const steps = db.prepare('SELECT COUNT(*) as count FROM preparation_steps WHERE productId = ?').get(product.id);
  const stepCount = steps.count;
  
  if (stepCount > 0) {
    withSteps++;
    console.log(`✅ ${product.code} - ${product.name} (${stepCount} passos)`);
  } else {
    withoutSteps++;
    console.log(`❌ ${product.code} - ${product.name} (SEM PASSOS)`);
  }
});

console.log(`\n=== RESUMO ===`);
console.log(`Produtos COM passo a passo: ${withSteps}`);
console.log(`Produtos SEM passo a passo: ${withoutSteps}`);

db.close();
