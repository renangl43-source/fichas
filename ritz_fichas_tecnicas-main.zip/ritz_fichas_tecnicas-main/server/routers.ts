import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import { getDb } from "./db";
import { storagePut } from "./storage";
import * as XLSX from 'xlsx';
import { eq } from "drizzle-orm";
import { ingredients, packaging, preparationSteps } from "../drizzle/schema";
import puppeteer from 'puppeteer';

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Acesso negado. Apenas administradores podem realizar esta ação.' });
  }
  return next({ ctx });
});

// Validation schemas
const ingredientSchema = z.object({
  name: z.string().min(1, "Nome do ingrediente é obrigatório"),
  quantity: z.string().min(1, "Quantidade é obrigatória"),
  unit: z.string().min(1, "Unidade é obrigatória"),
  unitCost: z.string().min(1, "Custo unitário é obrigatório"),
  order: z.number().default(0),
});

const packagingSchema = z.object({
  name: z.string().min(1, "Nome da embalagem é obrigatório"),
  quantity: z.string().min(1, "Quantidade é obrigatória"),
  unitCost: z.string().min(1, "Custo unitário é obrigatório"),
  order: z.number().default(0),
});

const preparationStepSchema = z.object({
  stepNumber: z.number().min(1),
  title: z.string().min(1, "Título do passo é obrigatório"),
  description: z.string().min(1, "Descrição do passo é obrigatória"),
});

const createProductSchema = z.object({
  name: z.string().min(1, "Nome do produto é obrigatório"),
  code: z.string().min(1, "Código do produto é obrigatório"),
  category: z.string().min(1, "Categoria é obrigatória"),
  description: z.string().optional(),
  logoUrl: z.string().optional(),
  photoUrl: z.string().optional(),
  suggestedPrice: z.string().optional(),
  
  // Especificações Técnicas
  finalWeight: z.string().optional(),
  servingTemperature: z.string().optional(),
  productClassification: z.string().optional(),
  
  // Controle de Processo
  scoopType: z.string().optional(),
  
  // Segurança Alimentar
  foodSafetyNotes: z.string().optional(),
  
  // Padrão de Entrega
  deliveryStandards: z.string().optional(),
  
  ingredients: z.array(ingredientSchema),
  packaging: z.array(packagingSchema),
  steps: z.array(preparationStepSchema),
});

const updateProductSchema = createProductSchema.extend({
  id: z.number(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    // Public: list all products
    list: publicProcedure.query(async () => {
      return await db.getAllProducts();
    }),

    // Public: get product details with ingredients, packaging and steps
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const product = await db.getProductWithDetails(input.id);
        if (!product) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Produto não encontrado' });
        }
        return product;
      }),

    // Public: get unified product line with all sizes (300ml, 500ml, 700ml)
    getUnified: publicProcedure
      .input(z.object({ productLine: z.string() }))
      .query(async ({ input }) => {
        const unifiedData = await db.getUnifiedProductLine(input.productLine);
        if (!unifiedData || unifiedData.products.length === 0) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Linha de produto não encontrada' });
        }
        return unifiedData;
      }),

    // Admin: create product with all related data
    create: adminProcedure
      .input(createProductSchema)
      .mutation(async ({ input, ctx }) => {
        const { ingredients, packaging, steps, ...productData } = input;
        
        // Create product
        const productId = await db.createProduct({
          ...productData,
          createdBy: ctx.user.id,
        });

        // Create related records
        await Promise.all([
          db.createIngredients(productId, ingredients),
          db.createPackaging(productId, packaging),
          db.createPreparationSteps(productId, steps),
        ]);

        return { id: productId, success: true };
      }),

    // Admin: update product and all related data
    update: adminProcedure
      .input(updateProductSchema)
      .mutation(async ({ input }) => {
        const { id, ingredients, packaging, steps, ...productData } = input;
        
        // Check if product exists
        const existing = await db.getProductById(id);
        if (!existing) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Produto não encontrado' });
        }

        // Update product
        await db.updateProduct(id, productData);

        // Delete and recreate related records
        await Promise.all([
          db.deleteIngredientsByProductId(id),
          db.deletePackagingByProductId(id),
          db.deletePreparationStepsByProductId(id),
        ]);

        await Promise.all([
          db.createIngredients(id, ingredients),
          db.createPackaging(id, packaging),
          db.createPreparationSteps(id, steps),
        ]);

        return { success: true };
      }),

    // Admin: delete product
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const existing = await db.getProductById(input.id);
        if (!existing) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Produto não encontrado' });
        }

        await db.deleteProduct(input.id);
        return { success: true };
      }),

    // Admin: upload image to S3
    uploadImage: adminProcedure
      .input(z.object({
        base64Data: z.string(),
        filename: z.string(),
        mimeType: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Convert base64 to buffer
        const base64Data = input.base64Data.replace(/^data:image\/\w+;base64,/, '');
        const buffer = Buffer.from(base64Data, 'base64');
        
        // Generate unique filename
        const timestamp = Date.now();
        const randomSuffix = Math.random().toString(36).substring(7);
        const fileKey = `ritz-products/${timestamp}-${randomSuffix}-${input.filename}`;
        
        // Upload to S3
        const { url } = await storagePut(fileKey, buffer, input.mimeType);
        
        return { url };
      }),

    // Admin: import product from Excel
    importExcel: adminProcedure
      .input(z.object({
        fileBase64: z.string(),
      }))
      .mutation(async ({ input }) => {
        try {
          // Decodificar base64
          const buffer = Buffer.from(input.fileBase64, 'base64');
          
          // Ler planilha
          const workbook = XLSX.read(buffer, { type: 'buffer' });
          
          // Ler aba "Dados do Produto"
          const produtoSheet = workbook.Sheets['Dados do Produto'];
          if (!produtoSheet) throw new Error('Aba "Dados do Produto" não encontrada');
          
          const nome = String(produtoSheet['B3']?.v || '').trim();
          const codigo = String(produtoSheet['B4']?.v || '').trim();
          const categoria = String(produtoSheet['B5']?.v || '').trim();
          const descricao = String(produtoSheet['B6']?.v || '').trim();
          const precoSugerido = String(produtoSheet['B7']?.v || '0').replace(',', '.');
          const photoUrl = String(produtoSheet['B8']?.v || '').trim();
          
          // Validar campos obrigatórios
          if (!nome) {
            throw new Error('Nome do produto é obrigatório (célula B3)');
          }
          if (!codigo) {
            throw new Error('Código do produto é obrigatório (célula B4)');
          }
          if (!categoria) {
            throw new Error('Categoria do produto é obrigatória (célula B5)');
          }
          
          // Ler aba "Ingredientes"
          const ingredientesSheet = workbook.Sheets['Ingredientes'];
          const ingredientes = [];
          if (ingredientesSheet) {
            for (let row = 4; row <= 14; row++) {
              const nomeIng = ingredientesSheet[`A${row}`]?.v;
              if (nomeIng) {
                ingredientes.push({
                  name: String(nomeIng),
                  quantity: String(ingredientesSheet[`B${row}`]?.v || '0').replace(',', '.'),
                  unit: String(ingredientesSheet[`C${row}`]?.v || ''),
                  unitCost: String(ingredientesSheet[`D${row}`]?.v || '0').replace(',', '.'),
                  order: ingredientes.length,
                });
              }
            }
          }
          
          // Ler aba "Embalagens"
          const embalagensSheet = workbook.Sheets['Embalagens'];
          const embalagens = [];
          if (embalagensSheet) {
            for (let row = 4; row <= 14; row++) {
              const nomeEmb = embalagensSheet[`A${row}`]?.v;
              if (nomeEmb) {
                embalagens.push({
                  name: String(nomeEmb),
                  quantity: String(embalagensSheet[`B${row}`]?.v || '0').replace(',', '.'),
                  unitCost: String(embalagensSheet[`D${row}`]?.v || '0').replace(',', '.'),
                  order: embalagens.length,
                });
              }
            }
          }
          
          // Ler aba "Passos de Preparo"
          const passosSheet = workbook.Sheets['Passos de Preparo'];
          const passos = [];
          if (passosSheet) {
            for (let row = 4; row <= 14; row++) {
              const titulo = passosSheet[`B${row}`]?.v;
              if (titulo) {
                const stepNum = passosSheet[`A${row}`]?.v;
                const stepNumber: number = stepNum ? parseInt(String(stepNum)) : passos.length + 1;
                
                // Validar se stepNumber é um número válido
                if (isNaN(stepNumber)) {
                  continue; // Pular este passo se o número não for válido
                }
                
                passos.push({
                  stepNumber,
                  title: String(titulo),
                  description: String(passosSheet[`C${row}`]?.v || ''),
                });
              }
            }
          }
          
          // Criar produto no banco usando o schema existente
          const productData = {
            name: String(nome),
            code: String(codigo),
            category: String(categoria),
            description: String(descricao),
            logoUrl: '',
            photoUrl: String(photoUrl),
            suggestedPrice: precoSugerido,
            ingredients: ingredientes,
            packaging: embalagens,
            steps: passos,
          };
          
          // Validar com o schema
          const validated = createProductSchema.parse(productData);
          
          // Criar produto
          const productId = await db.createProduct({
            name: validated.name,
            code: validated.code,
            category: validated.category,
            description: validated.description || '',
            logoUrl: validated.logoUrl || '',
            photoUrl: String(photoUrl || ''),
            suggestedPrice: validated.suggestedPrice || '0',
            createdBy: 1, // Admin user
          });
          
          // Adicionar ingredientes
          await db.createIngredients(productId, validated.ingredients.map(ing => ({
            name: ing.name,
            quantity: ing.quantity,
            unit: ing.unit,
            unitCost: ing.unitCost,
            order: ing.order,
          })));
          
          // Adicionar embalagens
          await db.createPackaging(productId, validated.packaging.map(pkg => ({
            name: pkg.name,
            quantity: pkg.quantity,
            unitCost: pkg.unitCost,
            order: pkg.order,
          })));
          
          // Adicionar passos
          await db.createPreparationSteps(productId, validated.steps.map(step => ({
            stepNumber: step.stepNumber,
            title: step.title,
            description: step.description,
          })));
          
          return {
            success: true,
            productId,
            message: `Produto "${nome}" importado com sucesso!`,
          };
        } catch (error) {
          console.error('Erro ao importar planilha:', error);
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: error instanceof Error ? error.message : 'Erro ao processar planilha',
          });
        }
      }),

    // Public: export product to PDF
    exportPDF: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const puppeteer = await import('puppeteer');
        const product = await db.getProductWithDetails(input.id);
        if (!product) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Produto não encontrado' });
        }

        // Calculate costs
        const ingredientsCost = product.ingredients?.reduce((sum: number, ing: any) => {
          return sum + (parseFloat(ing.quantity) * parseFloat(ing.unitCost));
        }, 0) || 0;

        const packagingCost = product.packaging?.reduce((sum: number, pkg: any) => {
          return sum + (parseFloat(pkg.quantity) * parseFloat(pkg.unitCost));
        }, 0) || 0;

        const totalCost = ingredientsCost + packagingCost;
        const suggestedPrice = product.suggestedPrice ? parseFloat(product.suggestedPrice) : 0;
        const margin = suggestedPrice > 0 ? ((suggestedPrice - totalCost) / suggestedPrice) * 100 : 0;

        // Generate HTML for PDF
        const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; background: white; }
    .container { max-width: 800px; margin: 0 auto; }
    .header { background: #7c3aed; color: white; padding: 20px; }
    .header h1 { font-size: 24px; margin-bottom: 5px; }
    .header p { font-size: 12px; opacity: 0.9; }
    .product-photo { background: linear-gradient(135deg, #fbbf24, #f59e0b); padding: 40px; text-align: center; min-height: 300px; display: flex; align-items: center; justify-content: center; }
    .product-photo img { max-height: 250px; max-width: 100%; object-fit: contain; }
    .content { padding: 20px; }
    .section { margin-bottom: 20px; page-break-inside: avoid; }
    .section-title { font-size: 16px; font-weight: bold; color: #7c3aed; border-bottom: 2px solid #fbbf24; padding-bottom: 5px; margin-bottom: 10px; }
    .badge { display: inline-block; background: #e5e7eb; padding: 4px 12px; border-radius: 4px; font-size: 12px; margin-bottom: 10px; }
    .step { display: flex; gap: 10px; margin-bottom: 10px; }
    .step-number { width: 30px; height: 30px; background: #7c3aed; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; flex-shrink: 0; }
    .step-content h4 { font-size: 14px; margin-bottom: 4px; }
    .step-content p { font-size: 12px; color: #666; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; }
    th { text-align: left; padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold; }
    td { padding: 8px; border-bottom: 1px solid #eee; }
    .text-right { text-align: right; }
    .specs-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .spec-box { background: #f3f4f6; padding: 10px; border-radius: 4px; }
    .spec-label { font-size: 10px; color: #666; margin-bottom: 4px; }
    .spec-value { font-size: 14px; font-weight: bold; }
    .safety-box { background: #fef2f2; border: 2px solid #fca5a5; padding: 15px; border-radius: 4px; }
    .safety-title { color: #b91c1c; font-size: 14px; font-weight: bold; margin-bottom: 10px; }
    .delivery-box { background: #eff6ff; border: 2px solid #93c5fd; padding: 15px; border-radius: 4px; }
    .delivery-title { color: #1e40af; font-size: 14px; font-weight: bold; margin-bottom: 10px; }
    .financial-box { background: #7c3aed; color: white; padding: 15px; border-radius: 4px; }
    .financial-title { font-size: 14px; font-weight: bold; margin-bottom: 10px; }
    .financial-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 12px; }
    .footer { background: #fbbf24; padding: 10px; text-align: center; font-size: 12px; font-weight: bold; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${product.name}</h1>
      <p>Código: ${product.code}</p>
    </div>
    
    ${product.photoUrl ? `
    <div class="product-photo">
      <img src="${product.photoUrl}" alt="${product.name}">
    </div>
    ` : ''}
    
    <div class="content">
      <div class="section">
        <span class="badge">${product.category}</span>
        ${product.description ? `<p style="color: #666; font-size: 14px;">${product.description}</p>` : ''}
      </div>

      ${(product.finalWeight || product.servingTemperature || product.productClassification || product.scoopType) ? `
      <div class="section">
        <div class="section-title">Especificações Técnicas</div>
        <div class="specs-grid">
          ${product.finalWeight ? `
          <div class="spec-box">
            <div class="spec-label">Peso Final Padrão</div>
            <div class="spec-value">${product.finalWeight}</div>
          </div>
          ` : ''}
          ${product.servingTemperature ? `
          <div class="spec-box">
            <div class="spec-label">Temperatura de Serviço</div>
            <div class="spec-value">${product.servingTemperature}</div>
          </div>
          ` : ''}
          ${product.productClassification ? `
          <div class="spec-box">
            <div class="spec-label">Classificação</div>
            <div class="spec-value">${product.productClassification}</div>
          </div>
          ` : ''}
          ${product.scoopType ? `
          <div class="spec-box">
            <div class="spec-label">Colher Dosadora</div>
            <div class="spec-value">${product.scoopType}</div>
          </div>
          ` : ''}
        </div>
      </div>
      ` : ''}

      ${product.steps && product.steps.length > 0 ? `
      <div class="section">
        <div class="section-title">Passo a Passo de Montagem</div>
        ${product.steps.map((step: any) => `
        <div class="step">
          <div class="step-number">${step.stepNumber}</div>
          <div class="step-content">
            <h4>${step.title}</h4>
            <p>${step.description}</p>
          </div>
        </div>
        `).join('')}
      </div>
      ` : ''}

      ${product.ingredients && product.ingredients.length > 0 ? `
      <div class="section">
        <div class="section-title">Ingredientes</div>
        <table>
          <thead>
            <tr>
              <th>Ingrediente</th>
              <th class="text-right">Quantidade</th>
              <th class="text-right">Custo Unit.</th>
              <th class="text-right">Custo Total</th>
            </tr>
          </thead>
          <tbody>
            ${product.ingredients.map((ing: any) => {
              const itemCost = parseFloat(ing.quantity) * parseFloat(ing.unitCost);
              return `
            <tr>
              <td>${ing.name}</td>
              <td class="text-right">${parseFloat(ing.quantity).toFixed(2).replace('.', ',')} ${ing.unit}</td>
              <td class="text-right">R$ ${parseFloat(ing.unitCost).toFixed(2).replace('.', ',')}</td>
              <td class="text-right"><strong>R$ ${itemCost.toFixed(2).replace('.', ',')}</strong></td>
            </tr>
              `;
            }).join('')}
            <tr style="font-weight: bold;">
              <td colspan="3" class="text-right">Subtotal Ingredientes:</td>
              <td class="text-right">R$ ${ingredientsCost.toFixed(2).replace('.', ',')}</td>
            </tr>
          </tbody>
        </table>
      </div>
      ` : ''}

      ${product.packaging && product.packaging.length > 0 ? `
      <div class="section">
        <div class="section-title">Embalagens</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th class="text-right">Quantidade</th>
              <th class="text-right">Custo Unit.</th>
              <th class="text-right">Custo Total</th>
            </tr>
          </thead>
          <tbody>
            ${product.packaging.map((pkg: any) => {
              const itemCost = parseFloat(pkg.quantity) * parseFloat(pkg.unitCost);
              return `
            <tr>
              <td>${pkg.name}</td>
              <td class="text-right">${parseFloat(pkg.quantity).toFixed(2).replace('.', ',')}</td>
              <td class="text-right">R$ ${parseFloat(pkg.unitCost).toFixed(2).replace('.', ',')}</td>
              <td class="text-right"><strong>R$ ${itemCost.toFixed(2).replace('.', ',')}</strong></td>
            </tr>
              `;
            }).join('')}
            <tr style="font-weight: bold;">
              <td colspan="3" class="text-right">Subtotal Embalagens:</td>
              <td class="text-right">R$ ${packagingCost.toFixed(2).replace('.', ',')}</td>
            </tr>
          </tbody>
        </table>
      </div>
      ` : ''}

      ${product.foodSafetyNotes ? `
      <div class="section">
        <div class="safety-box">
          <div class="safety-title">⚠️ Segurança Alimentar</div>
          <div style="font-size: 12px; white-space: pre-line;">${product.foodSafetyNotes}</div>
        </div>
      </div>
      ` : ''}

      ${product.deliveryStandards ? `
      <div class="section">
        <div class="delivery-box">
          <div class="delivery-title">Padrão de Entrega ao Cliente</div>
          <div style="font-size: 12px; white-space: pre-line;">${product.deliveryStandards}</div>
        </div>
      </div>
      ` : ''}

      <div class="section">
        <div class="financial-box">
          <div class="financial-title">Informações Financeiras</div>
          <div class="financial-row">
            <span>Custo Total:</span>
            <span><strong>R$ ${totalCost.toFixed(2).replace('.', ',')}</strong></span>
          </div>
          ${suggestedPrice > 0 ? `
          <div class="financial-row">
            <span>Preço Sugerido:</span>
            <span><strong>R$ ${suggestedPrice.toFixed(2).replace('.', ',')}</strong></span>
          </div>
          <div class="financial-row">
            <span>Margem de Lucro:</span>
            <span><strong>${margin.toFixed(2).replace('.', ',')}%</strong></span>
          </div>
          ` : ''}
        </div>
      </div>
    </div>
    
    <div class="footer">
      Revisão: ${new Date(product.updatedAt).toLocaleDateString('pt-BR')} | Ritz Sorvetes
    </div>
  </div>
</body>
</html>
        `;

        // Launch browser and generate PDF
        const browser = await puppeteer.launch({
          headless: true,
          args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'networkidle0' });
        const pdfBuffer = await page.pdf({
          format: 'A4',
          printBackground: true,
          margin: { top: '0', right: '0', bottom: '0', left: '0' }
        });
        await browser.close();

        // Convert to base64
        const base64PDF = Buffer.from(pdfBuffer).toString('base64');
        
        return { 
          success: true, 
          pdfBase64: base64PDF,
          filename: `ficha-tecnica-${product.code}.pdf`
        };
      }),

    // Export PDF - Attendant Version (without costs)
    exportPDFAttendant: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const product = await db.getProductById(input.id);
        if (!product) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Produto não encontrado' });
        }

        const dbInstance = await getDb();
        if (!dbInstance) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Database not available' });
        
        const [ingredientsData, packagingData, stepsData] = await Promise.all([
          dbInstance.select().from(ingredients).where(eq(ingredients.productId, input.id)).orderBy(ingredients.order),
          dbInstance.select().from(packaging).where(eq(packaging.productId, input.id)).orderBy(packaging.order),
          dbInstance.select().from(preparationSteps).where(eq(preparationSteps.productId, input.id)).orderBy(preparationSteps.stepNumber),
        ]);

        // HTML template for attendant version (without costs)
        const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; padding: 20px; }
    .container { max-width: 800px; margin: 0 auto; }
    .header { background: linear-gradient(135deg, #7c3aed 0%, #fbbf24 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
    .header h1 { font-size: 28px; margin-bottom: 5px; }
    .header p { font-size: 14px; opacity: 0.9; }
    .content { background: white; padding: 30px; border: 2px solid #7c3aed; border-top: none; border-radius: 0 0 10px 10px; }
    .section { margin-bottom: 25px; }
    .section-title { color: #7c3aed; font-size: 18px; font-weight: bold; margin-bottom: 15px; padding-bottom: 8px; border-bottom: 2px solid #fbbf24; }
    .step { margin-bottom: 15px; padding: 15px; background: #f9fafb; border-left: 4px solid #7c3aed; border-radius: 5px; }
    .step-number { display: inline-block; background: #7c3aed; color: white; width: 30px; height: 30px; line-height: 30px; text-align: center; border-radius: 50%; margin-right: 10px; font-weight: bold; }
    .step-title { font-weight: bold; color: #1f2937; margin-bottom: 5px; }
    .step-desc { color: #4b5563; line-height: 1.6; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
    th { background: #f3f4f6; color: #374151; font-weight: 600; }
    .info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
    .info-item { background: #f9fafb; padding: 15px; border-radius: 8px; border-left: 3px solid #7c3aed; }
    .info-label { font-size: 12px; color: #6b7280; text-transform: uppercase; margin-bottom: 5px; }
    .info-value { font-size: 16px; color: #1f2937; font-weight: 600; }
    .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 2px solid #e5e7eb; color: #6b7280; font-size: 12px; }
    .watermark { text-align: center; margin-top: 10px; color: #7c3aed; font-weight: bold; font-size: 14px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${product.name}</h1>
      <p>Código: ${product.code} | Versão Atendente</p>
    </div>
    
    <div class="content">
      ${product.photoUrl ? `
      <div class="section" style="text-align: center; margin-bottom: 20px;">
        <img src="${product.photoUrl}" alt="${product.name}" style="max-width: 300px; max-height: 300px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);" />
      </div>
      ` : ''}
      ${product.description ? `
      <div class="section">
        <p style="color: #4b5563; line-height: 1.6;">${product.description}</p>
      </div>
      ` : ''}

      <div class="section">
        <h2 class="section-title">Passo a Passo de Montagem</h2>
        ${stepsData.map((step: any) => `
          <div class="step">
            <span class="step-number">${step.stepNumber}</span>
            <div style="display: inline-block; width: calc(100% - 50px); vertical-align: top;">
              <div class="step-title">${step.title}</div>
              <div class="step-desc">${step.description}</div>
            </div>
          </div>
        `).join('')}
      </div>

      <div class="section">
        <h2 class="section-title">Ingredientes</h2>
        <table>
          <thead>
            <tr>
              <th>Ingrediente</th>
              <th>Quantidade</th>
            </tr>
          </thead>
          <tbody>
            ${ingredientsData.map((ing: any) => `
              <tr>
                <td>${ing.name}</td>
                <td>${parseFloat(ing.quantity).toFixed(2).replace('.', ',')} ${ing.unit}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <div class="section">
        <h2 class="section-title">Embalagens</h2>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantidade</th>
            </tr>
          </thead>
          <tbody>
            ${packagingData.map((pkg: any) => `
              <tr>
                <td>${pkg.name}</td>
                <td>${parseFloat(pkg.quantity).toFixed(2).replace('.', ',')}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      ${product.finalWeight || product.servingTemperature || product.productClassification || product.scoopType ? `
      <div class="section">
        <h2 class="section-title">Especificações Técnicas</h2>
        <div class="info-grid">
          ${product.finalWeight ? `
          <div class="info-item">
            <div class="info-label">Peso Final Padrão</div>
            <div class="info-value">${product.finalWeight}</div>
          </div>
          ` : ''}
          ${product.servingTemperature ? `
          <div class="info-item">
            <div class="info-label">Temperatura de Serviço</div>
            <div class="info-value">${product.servingTemperature}</div>
          </div>
          ` : ''}
          ${product.productClassification ? `
          <div class="info-item">
            <div class="info-label">Classificação</div>
            <div class="info-value">${product.productClassification}</div>
          </div>
          ` : ''}
          ${product.scoopType ? `
          <div class="info-item">
            <div class="info-label">Colher Dosadora</div>
            <div class="info-value">${product.scoopType}</div>
          </div>
          ` : ''}
        </div>
      </div>
      ` : ''}

      ${product.foodSafetyNotes ? `
      <div class="section">
        <h2 class="section-title">Segurança Alimentar</h2>
        <p style="color: #4b5563; line-height: 1.8;">${product.foodSafetyNotes}</p>
      </div>
      ` : ''}

      ${product.deliveryStandards ? `
      <div class="section">
        <h2 class="section-title">Padrão de Entrega ao Cliente</h2>
        <p style="color: #4b5563; line-height: 1.8;">${product.deliveryStandards}</p>
      </div>
      ` : ''}

      <div class="watermark">VERSÃO ATENDENTE - SEM INFORMAÇÕES FINANCEIRAS</div>
    </div>
    
    <div class="footer">
      Revisão: ${new Date(product.updatedAt).toLocaleDateString('pt-BR')} | Ritz Sorvetes
    </div>
  </div>
</body>
</html>
        `;

        // Launch browser and generate PDF
        const browser = await puppeteer.launch({
          headless: true,
          args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'networkidle0' });
        const pdfBuffer = await page.pdf({
          format: 'A4',
          printBackground: true,
          margin: { top: '0', right: '0', bottom: '0', left: '0' }
        });
        await browser.close();

        // Convert to base64
        const base64PDF = Buffer.from(pdfBuffer).toString('base64');
        
        return { 
          success: true, 
          pdfBase64: base64PDF,
          filename: `ficha-tecnica-atendente-${product.code}.pdf`
        };
      }),

    // Export ALL products as single PDF - Attendant Version
    exportAllPDFAttendant: protectedProcedure
      .mutation(async () => {
        const allProducts = await db.getAllProducts();
        if (!allProducts || allProducts.length === 0) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Nenhum produto encontrado' });
        }

        const dbInstance = await getDb();
        if (!dbInstance) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Database not available' });
        
        // Generate HTML for all products
        const productHTMLs = await Promise.all(
          allProducts.map(async (product) => {
            const [ingredientsData, packagingData, stepsData] = await Promise.all([
              dbInstance.select().from(ingredients).where(eq(ingredients.productId, product.id)).orderBy(ingredients.order),
              dbInstance.select().from(packaging).where(eq(packaging.productId, product.id)).orderBy(packaging.order),
              dbInstance.select().from(preparationSteps).where(eq(preparationSteps.productId, product.id)).orderBy(preparationSteps.stepNumber),
            ]);

            return `
    <div class="product-page" style="page-break-after: always;">
      <div class="header">
        <h1>${product.name}</h1>
        <p>Código: ${product.code} | Versão Atendente</p>
      </div>
      
      <div class="content">
        ${product.photoUrl ? `
        <div class="section" style="text-align: center; margin-bottom: 20px;">
          <img src="${product.photoUrl}" alt="${product.name}" style="max-width: 300px; max-height: 300px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);" />
        </div>
        ` : ''}
        ${product.description ? `
        <div class="section">
          <p style="color: #4b5563; line-height: 1.6;">${product.description}</p>
        </div>
        ` : ''}

        ${stepsData.length > 0 ? `
        <div class="section">
          <h2 class="section-title">Passo a Passo de Montagem</h2>
          ${stepsData.map((step: any) => `
            <div class="step">
              <span class="step-number">${step.stepNumber}</span>
              <div style="display: inline-block; width: calc(100% - 50px); vertical-align: top;">
                <div class="step-title">${step.title}</div>
                <div class="step-desc">${step.description}</div>
              </div>
            </div>
          `).join('')}
        </div>
        ` : ''}

        ${ingredientsData.length > 0 ? `
        <div class="section">
          <h2 class="section-title">Ingredientes</h2>
          <table>
            <thead>
              <tr>
                <th>Ingrediente</th>
                <th>Quantidade</th>
              </tr>
            </thead>
            <tbody>
              ${ingredientsData.map((ing: any) => `
                <tr>
                  <td>${ing.name}</td>
                  <td>${parseFloat(ing.quantity).toFixed(2).replace('.', ',')} ${ing.unit}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        ` : ''}

        ${packagingData.length > 0 ? `
        <div class="section">
          <h2 class="section-title">Embalagens</h2>
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th>Quantidade</th>
              </tr>
            </thead>
            <tbody>
              ${packagingData.map((pkg: any) => `
                <tr>
                  <td>${pkg.name}</td>
                  <td>${parseFloat(pkg.quantity).toFixed(2).replace('.', ',')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
        ` : ''}

        <div class="watermark">VERSÃO ATENDENTE - SEM INFORMAÇÕES FINANCEIRAS</div>
      </div>
      
      <div class="footer">
        Revisão: ${new Date(product.updatedAt).toLocaleDateString('pt-BR')} | Ritz Sorvetes
      </div>
    </div>
            `;
          })
        );

        const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Arial, sans-serif; }
    .product-page { padding: 20px; }
    .container { max-width: 800px; margin: 0 auto; }
    .header { background: linear-gradient(135deg, #7c3aed 0%, #fbbf24 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
    .header h1 { font-size: 28px; margin-bottom: 5px; }
    .header p { font-size: 14px; opacity: 0.9; }
    .content { background: white; padding: 30px; border: 2px solid #7c3aed; border-top: none; border-radius: 0 0 10px 10px; }
    .section { margin-bottom: 25px; }
    .section-title { color: #7c3aed; font-size: 18px; font-weight: bold; margin-bottom: 15px; padding-bottom: 8px; border-bottom: 2px solid #fbbf24; }
    .step { margin-bottom: 15px; padding: 15px; background: #f9fafb; border-left: 4px solid #7c3aed; border-radius: 5px; }
    .step-number { display: inline-block; background: #7c3aed; color: white; width: 30px; height: 30px; line-height: 30px; text-align: center; border-radius: 50%; margin-right: 10px; font-weight: bold; }
    .step-title { font-weight: bold; color: #1f2937; margin-bottom: 5px; }
    .step-desc { color: #4b5563; line-height: 1.6; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
    th { background: #f3f4f6; color: #374151; font-weight: 600; }
    .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 2px solid #e5e7eb; color: #6b7280; font-size: 12px; }
    .watermark { text-align: center; margin-top: 10px; color: #7c3aed; font-weight: bold; font-size: 14px; }
  </style>
</head>
<body>
  ${productHTMLs.join('\n')}
</body>
</html>
        `;

        // Launch browser and generate PDF
        const browser = await puppeteer.launch({
          headless: true,
          args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: 'networkidle0' });
        const pdfBuffer = await page.pdf({
          format: 'A4',
          printBackground: true,
          margin: { top: '0', right: '0', bottom: '0', left: '0' }
        });
        await browser.close();

        // Convert to base64
        const base64PDF = Buffer.from(pdfBuffer).toString('base64');
        
        return { 
          success: true, 
          pdfBase64: base64PDF,
          filename: `fichas-tecnicas-atendente-completo.pdf`,
          productCount: allProducts.length
        };
      }),
  }),

  // Base Ingredients router
  baseIngredients: router({
    list: protectedProcedure.query(async () => {
      return await db.getAllBaseIngredients();
    }),

    search: protectedProcedure
      .input(z.object({ query: z.string() }))
      .query(async ({ input }) => {
        const allIngredients = await db.getAllBaseIngredients();
        const query = input.query.toLowerCase().trim();
        
        if (!query) return allIngredients;
        
        return allIngredients.filter((ing: any) => 
          ing.name.toLowerCase().includes(query)
        );
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const ingredient = await db.getBaseIngredientById(input.id);
        if (!ingredient) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Ingrediente não encontrado' });
        }
        return ingredient;
      }),

    create: adminProcedure
      .input(z.object({
        name: z.string().min(1, "Nome é obrigatório"),
        purchaseUnit: z.string().min(1, "Unidade de compra é obrigatória"),
        purchaseQuantity: z.number().min(1, "Quantidade deve ser maior que zero"),
        purchasePrice: z.number().min(0, "Preço deve ser maior ou igual a zero"),
        usageUnit: z.string().min(1, "Unidade de uso é obrigatória"),
      }))
      .mutation(async ({ input }) => {
        const getConversionFactor = (purchaseUnit: string, usageUnit: string): number => {
          const normalizedPurchase = purchaseUnit.toLowerCase().trim();
          const normalizedUsage = usageUnit.toLowerCase().trim();

          if (normalizedPurchase === 'kg' && normalizedUsage === 'g') return 1000;
          if (normalizedPurchase === 'kg' && normalizedUsage === 'kg') return 1;
          if (normalizedPurchase === 'g' && normalizedUsage === 'g') return 1;
          if (normalizedPurchase === 'g' && normalizedUsage === 'kg') return 0.001;

          if (normalizedPurchase === 'l' && normalizedUsage === 'ml') return 1000;
          if (normalizedPurchase === 'l' && normalizedUsage === 'l') return 1;
          if (normalizedPurchase === 'ml' && normalizedUsage === 'ml') return 1;
          if (normalizedPurchase === 'ml' && normalizedUsage === 'l') return 0.001;

          return 1;
        };

        const conversionFactor = getConversionFactor(input.purchaseUnit, input.usageUnit);
        const totalUnits = input.purchaseQuantity * conversionFactor;
        const unitCost = Math.round(input.purchasePrice / totalUnits);
        
        await db.createBaseIngredient({
          ...input,
          unitCost,
        });
        
        return { success: true, message: 'Ingrediente cadastrado com sucesso!' };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        purchaseUnit: z.string().min(1).optional(),
        purchaseQuantity: z.number().min(1).optional(),
        purchasePrice: z.number().min(0).optional(),
        usageUnit: z.string().min(1).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        
        // Recalcular custo unitário se preço, quantidade ou unidades mudaram
        if (data.purchasePrice !== undefined || data.purchaseQuantity !== undefined || data.purchaseUnit !== undefined || data.usageUnit !== undefined) {
          const current = await db.getBaseIngredientById(id);
          if (!current) {
            throw new TRPCError({ code: 'NOT_FOUND', message: 'Ingrediente não encontrado' });
          }

          const getConversionFactor = (purchaseUnit: string, usageUnit: string): number => {
            const normalizedPurchase = purchaseUnit.toLowerCase().trim();
            const normalizedUsage = usageUnit.toLowerCase().trim();

            if (normalizedPurchase === 'kg' && normalizedUsage === 'g') return 1000;
            if (normalizedPurchase === 'kg' && normalizedUsage === 'kg') return 1;
            if (normalizedPurchase === 'g' && normalizedUsage === 'g') return 1;
            if (normalizedPurchase === 'g' && normalizedUsage === 'kg') return 0.001;

            if (normalizedPurchase === 'l' && normalizedUsage === 'ml') return 1000;
            if (normalizedPurchase === 'l' && normalizedUsage === 'l') return 1;
            if (normalizedPurchase === 'ml' && normalizedUsage === 'ml') return 1;
            if (normalizedPurchase === 'ml' && normalizedUsage === 'l') return 0.001;

            return 1;
          };
          
          const newPrice = data.purchasePrice ?? current.purchasePrice;
          const newQuantity = data.purchaseQuantity ?? current.purchaseQuantity;
          const newPurchaseUnit = data.purchaseUnit ?? current.purchaseUnit;
          const newUsageUnit = data.usageUnit ?? current.usageUnit;

          const conversionFactor = getConversionFactor(newPurchaseUnit, newUsageUnit);
          const totalUnits = newQuantity * conversionFactor;
          (data as any).unitCost = Math.round(newPrice / totalUnits);
        }
        
        await db.updateBaseIngredient(id, data);
        return { success: true, message: 'Ingrediente atualizado com sucesso!' };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteBaseIngredient(input.id);
        return { success: true, message: 'Ingrediente excluído com sucesso!' };
      }),
  }),

  // Product line synchronization
  productLine: router({
    // Validate if all products in a line have identical preparation steps
    validate: adminProcedure
      .input(z.object({ productLine: z.string() }))
      .query(async ({ input }) => {
        const isValid = await db.validatePreparationSteps(input.productLine);
        return { isValid, productLine: input.productLine };
      }),

    // Synchronize preparation steps across all products in a line
    sync: adminProcedure
      .input(z.object({ productLine: z.string() }))
      .mutation(async ({ input }) => {
        const result = await db.syncPreparationSteps(input.productLine);
        return {
          success: true,
          message: `Sincronizado ${result.synced} produto(s) com ${result.reference}`,
          ...result,
        };
      }),

    // Get all product lines with validation status
    listWithStatus: adminProcedure
      .query(async () => {
        const productLines = [
          'copo-kids',
          'copo-moranguete',
          'copo-seducao',
          'copo-sensacoes',
          'pistache-intenso',
          'copo-choco-duo',
          'copo-caribe',
          'copo-dois-amores',
          'copo-dadinho',
          'tercai',
          'acai-tradicional',
        ];

        const results = await Promise.all(
          productLines.map(async (line) => {
            const products = await db.getProductsByLine(line);
            const isValid = products.length > 1 ? await db.validatePreparationSteps(line) : true;
            return {
              productLine: line,
              productCount: products.length,
              isValid,
              needsSync: !isValid,
            };
          })
        );

        return results;
      }),
  }),
});

export type AppRouter = typeof appRouter;
