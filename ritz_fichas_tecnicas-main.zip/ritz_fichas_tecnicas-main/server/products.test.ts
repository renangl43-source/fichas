import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createMockContext(role: "admin" | "user" = "admin"): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("products router", () => {
  describe("list", () => {
    it("should return an array of products", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.products.list();

      expect(Array.isArray(result)).toBe(true);
    });

    it("should work without authentication", async () => {
      const ctx: TrpcContext = {
        user: undefined,
        req: {
          protocol: "https",
          headers: {},
        } as TrpcContext["req"],
        res: {} as TrpcContext["res"],
      };
      const caller = appRouter.createCaller(ctx);

      const result = await caller.products.list();

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("create", () => {
    it("should reject non-admin users", async () => {
      const ctx = createMockContext("user");
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.products.create({
          name: "Test Product",
          code: "TEST001",
          category: "Test",
          description: "Test description",
          ingredients: [],
          packaging: [],
          steps: [],
        })
      ).rejects.toThrow("Acesso negado");
    });

    it("should allow admin users to create products", async () => {
      const ctx = createMockContext("admin");
      const caller = appRouter.createCaller(ctx);

      const result = await caller.products.create({
        name: "Açaí Tradicional 500ml",
        code: "ACAI-500",
        category: "Açaís",
        description: "Açaí tradicional de 500ml",
        suggestedPrice: "15.00",
        ingredients: [
          {
            name: "Açaí Ritz",
            quantity: "300",
            unit: "g",
            unitCost: "0.02",
            order: 0,
          },
        ],
        packaging: [
          {
            name: "Copo 500ml",
            quantity: "1",
            unitCost: "0.50",
            order: 0,
          },
        ],
        steps: [
          {
            stepNumber: 1,
            title: "BASE - PRIMEIRA CAMADA",
            description: "Adicionar 300g de açaí Ritz no copo",
          },
        ],
      });

      expect(result.success).toBe(true);
      expect(result.id).toBeGreaterThan(0);
    });
  });

  describe("delete", () => {
    it("should reject non-admin users", async () => {
      const ctx = createMockContext("user");
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.products.delete({ id: 999 })
      ).rejects.toThrow("Acesso negado");
    });
  });

  describe("uploadImage", () => {
    it("should reject non-admin users", async () => {
      const ctx = createMockContext("user");
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.products.uploadImage({
          base64Data: "data:image/png;base64,test",
          filename: "test.png",
          mimeType: "image/png",
        })
      ).rejects.toThrow("Acesso negado");
    });
  });
});
