import PDFDocument from 'pdfkit';

export interface ProductData {
  id: number;
  name: string;
  code: string;
  category: string;
  description: string;
  totalCost: number;
  suggestedPrice: number;
  marginPercent: number;
  ingredients: Array<{
    name: string;
    quantity: string;
    unitCost: number;
    totalCost: number;
  }>;
  packaging: Array<{
    name: string;
    quantity: number;
    unitCost: number;
    totalCost: number;
  }>;
  steps: Array<{
    stepNumber: number;
    title: string;
    description: string;
  }>;
  checklist: string[];
}

/**
 * Gera PDF completo com todas as informações do produto
 */
export function generateCompletePDF(product: ProductData): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'A4',
        margin: 40,
      });

      const chunks: Buffer[] = [];

      doc.on('data', (chunk: Buffer) => {
        chunks.push(chunk);
      });

      doc.on('end', () => {
        resolve(Buffer.concat(chunks));
      });

      doc.on('error', (err: Error) => {
        reject(new Error(`Erro ao gerar PDF: ${err.message}`));
      });

      // Cabeçalho
      doc.fontSize(24).font('Helvetica-Bold').text('Ficha Técnica Completa', { align: 'center' });
      doc.fontSize(10).font('Helvetica').text('Ritz Sorvetes', { align: 'center' });
      doc.moveDown(0.5);

      // Informações do Produto
      doc.fontSize(14).font('Helvetica-Bold').text(product.name);
      doc.fontSize(10).font('Helvetica').text(`Código: ${product.code}`);
      doc.fontSize(10).text(`Categoria: ${product.category}`);
      doc.fontSize(10).text(`Descrição: ${product.description}`);
      doc.moveDown(0.5);

      // Informações Financeiras
      doc.fontSize(12).font('Helvetica-Bold').text('Informações Financeiras');
      doc.fontSize(10).font('Helvetica');
      doc.text(`Custo Total: R$ ${product.totalCost.toFixed(2)}`);
      doc.text(`Preço Sugerido: R$ ${product.suggestedPrice.toFixed(2)}`);
      doc.text(`Margem de Lucro: ${product.marginPercent.toFixed(2)}%`);
      doc.moveDown(0.5);

      // Ingredientes
      if (product.ingredients.length > 0) {
        doc.fontSize(12).font('Helvetica-Bold').text('Ingredientes');
        doc.fontSize(9).font('Helvetica');
        
        const ingredientRows = [
          ['Ingrediente', 'Quantidade', 'Custo Unit.', 'Custo Total'],
          ...product.ingredients.map(ing => [
            ing.name,
            ing.quantity,
            `R$ ${ing.unitCost.toFixed(2)}`,
            `R$ ${ing.totalCost.toFixed(2)}`
          ])
        ];

        drawTable(doc, ingredientRows, 50);
        doc.moveDown(0.5);
      }

      // Embalagens
      if (product.packaging.length > 0) {
        doc.fontSize(12).font('Helvetica-Bold').text('Embalagens');
        doc.fontSize(9).font('Helvetica');
        
        const packagingRows = [
          ['Item', 'Quantidade', 'Custo Unit.', 'Custo Total'],
          ...product.packaging.map(pkg => [
            pkg.name,
            pkg.quantity.toString(),
            `R$ ${pkg.unitCost.toFixed(2)}`,
            `R$ ${pkg.totalCost.toFixed(2)}`
          ])
        ];

        drawTable(doc, packagingRows, 50);
        doc.moveDown(0.5);
      }

      // Passo a Passo
      if (product.steps.length > 0) {
        doc.fontSize(12).font('Helvetica-Bold').text('Passo a Passo de Montagem');
        doc.fontSize(10).font('Helvetica');
        
        product.steps.forEach(step => {
          doc.text(`${step.stepNumber}. ${step.title}`, { continued: false });
          doc.fontSize(9).text(step.description);
          doc.fontSize(10);
          doc.moveDown(0.3);
        });
        doc.moveDown(0.5);
      }

      // Checklist
      if (product.checklist.length > 0) {
        doc.fontSize(12).font('Helvetica-Bold').text('Checklist de Entrega');
        doc.fontSize(10).font('Helvetica');
        
        product.checklist.forEach(item => {
          doc.text(`☐ ${item}`);
        });
      }

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Gera PDF simplificado para atendentes (versão resumida)
 */
export function generateAttendantPDF(product: ProductData): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'A4',
        margin: 40,
      });

      const chunks: Buffer[] = [];

      doc.on('data', (chunk: Buffer) => {
        chunks.push(chunk);
      });

      doc.on('end', () => {
        resolve(Buffer.concat(chunks));
      });

      doc.on('error', (err: Error) => {
        reject(new Error(`Erro ao gerar PDF: ${err.message}`));
      });

      // Cabeçalho
      doc.fontSize(20).font('Helvetica-Bold').text('FICHA DE ATENDENTE', { align: 'center' });
      doc.fontSize(10).font('Helvetica').text('Ritz Sorvetes', { align: 'center' });
      doc.moveDown(0.5);

      // Informações do Produto
      doc.fontSize(16).font('Helvetica-Bold').text(product.name);
      doc.fontSize(11).font('Helvetica').text(`Código: ${product.code}`);
      doc.fontSize(11).text(`Categoria: ${product.category}`);
      doc.moveDown(0.5);

      // Passo a Passo (Foco Principal)
      doc.fontSize(14).font('Helvetica-Bold').text('Modo de Preparo');
      doc.fontSize(11).font('Helvetica');
      
      if (product.steps.length > 0) {
        product.steps.forEach(step => {
          doc.fontSize(12).font('Helvetica-Bold').text(`${step.stepNumber}. ${step.title}`);
          doc.fontSize(11).font('Helvetica').text(step.description);
          doc.moveDown(0.3);
        });
      } else {
        doc.text('Sem passos de montagem definidos.');
      }
      
      doc.moveDown(0.5);

      // Checklist
      if (product.checklist.length > 0) {
        doc.fontSize(12).font('Helvetica-Bold').text('Checklist de Entrega');
        doc.fontSize(11).font('Helvetica');
        
        product.checklist.forEach(item => {
          doc.text(`☐ ${item}`);
        });
      }

      // Rodapé com informações de custo (apenas para referência interna)
      doc.moveDown(1);
      doc.fontSize(9).font('Helvetica').text('─'.repeat(60), { align: 'center' });
      doc.fontSize(9).text(`Custo: R$ ${product.totalCost.toFixed(2)} | Preço: R$ ${product.suggestedPrice.toFixed(2)}`, { align: 'center' });

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Função auxiliar para desenhar tabelas no PDF
 */
function drawTable(doc: any, rows: string[][], startY: number) {
  const colWidths = [150, 80, 80, 80];
  const rowHeight = 20;
  let y = startY;

  rows.forEach((row, rowIndex) => {
    let x = 50;
    const isHeader = rowIndex === 0;

    if (isHeader) {
      doc.rect(x, y, 390, rowHeight).fill('#f0f0f0');
      doc.fillColor('#000000');
    }

    row.forEach((cell, colIndex) => {
      if (isHeader) {
        doc.fontSize(10).font('Helvetica-Bold');
      } else {
        doc.fontSize(9).font('Helvetica');
      }
      doc.text(cell, x + 5, y + 5, {
        width: colWidths[colIndex] - 10,
        align: 'left',
      });
      x += colWidths[colIndex];
    });

    y += rowHeight;
  });
}

/**
 * Fallback: Gera um PDF simples em caso de erro
 */
export function generateFallbackPDF(productName: string, error: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument();
      const chunks: Buffer[] = [];

      doc.on('data', (chunk: Buffer) => {
        chunks.push(chunk);
      });

      doc.on('end', () => {
        resolve(Buffer.concat(chunks));
      });

      doc.fontSize(16).text('Ficha Técnica', { align: 'center' });
      doc.fontSize(14).text(productName);
      doc.moveDown();
      doc.fontSize(10).text('Ritz Sorvetes');
      doc.moveDown(2);
      doc.fontSize(10).text('Nota: Esta é uma versão simplificada do documento.');
      doc.text('Para a ficha técnica completa, consulte o sistema.');

      doc.end();
    } catch (err) {
      reject(err);
    }
  });
}
