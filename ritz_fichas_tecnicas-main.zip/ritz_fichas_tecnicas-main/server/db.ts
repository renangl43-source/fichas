import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  products, 
  ingredients, 
  packaging, 
  preparationSteps,
  baseIngredients,
  InsertProduct,
  InsertIngredient,
  InsertPackaging,
  InsertPreparationStep,
  InsertBaseIngredient
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Product operations
export async function getAllProducts() {
  const db = await getDb();
  if (!db) return [];
  
  const allProducts = await db.select().from(products).orderBy(products.createdAt);
  
  // Buscar ingredientes para todos os produtos
  const productsWithIngredients = await Promise.all(
    allProducts.map(async (product) => {
      const productIngredients = await db.select().from(ingredients).where(eq(ingredients.productId, product.id));
      const productPackaging = await db.select().from(packaging).where(eq(packaging.productId, product.id));
      
      return {
        ...product,
        ingredients: productIngredients,
        packaging: productPackaging,
      };
    })
  );
  
  return productsWithIngredients;
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getProductWithDetails(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const product = await getProductById(id);
  if (!product) return undefined;
  
  const [productIngredients, productPackaging, steps] = await Promise.all([
    db.select().from(ingredients).where(eq(ingredients.productId, id)).orderBy(ingredients.order),
    db.select().from(packaging).where(eq(packaging.productId, id)).orderBy(packaging.order),
    db.select().from(preparationSteps).where(eq(preparationSteps.productId, id)).orderBy(preparationSteps.stepNumber),
  ]);
  
  return {
    ...product,
    ingredients: productIngredients,
    packaging: productPackaging,
    steps,
  };
}

/**
 * Get all products from the same product line (for unified technical sheets)
 * Returns products ordered by size (300ml, 500ml, 700ml)
 */
export async function getProductsByLine(productLine: string) {
  const db = await getDb();
  if (!db) return [];
  
  const sizeOrder = { '300ml': 1, '500ml': 2, '700ml': 3 };
  const lineProducts = await db.select().from(products).where(eq(products.productLine, productLine));
  
  // Sort by size order
  return lineProducts.sort((a, b) => {
    const orderA = sizeOrder[a.size as keyof typeof sizeOrder] || 999;
    const orderB = sizeOrder[b.size as keyof typeof sizeOrder] || 999;
    return orderA - orderB;
  });
}

/**
 * Get complete unified technical sheet for a product line
 * Includes all sizes with their ingredients, packaging, and steps
 */
export async function getUnifiedProductLine(productLine: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const lineProducts = await getProductsByLine(productLine);
  if (lineProducts.length === 0) return undefined;
  
  // Get details for each size
  const productsWithDetails = await Promise.all(
    lineProducts.map(async (product) => {
      const [productIngredients, productPackaging, steps] = await Promise.all([
        db.select().from(ingredients).where(eq(ingredients.productId, product.id)).orderBy(ingredients.order),
        db.select().from(packaging).where(eq(packaging.productId, product.id)).orderBy(packaging.order),
        db.select().from(preparationSteps).where(eq(preparationSteps.productId, product.id)).orderBy(preparationSteps.stepNumber),
      ]);
      
      return {
        ...product,
        ingredients: productIngredients,
        packaging: productPackaging,
        steps,
      };
    })
  );
  
  return {
    productLine,
    products: productsWithDetails,
    // Use first product's steps as reference (should be identical across sizes)
    steps: productsWithDetails[0]?.steps || [],
  };
}

export async function createProduct(data: InsertProduct) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(products).values(data);
  return result[0].insertId;
}

export async function updateProduct(id: number, data: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Convert empty strings to null for text fields to avoid MySQL errors
  const cleanedData = { ...data };
  if (cleanedData.foodSafetyNotes === '') cleanedData.foodSafetyNotes = null;
  if (cleanedData.deliveryStandards === '') cleanedData.deliveryStandards = null;
  if (cleanedData.description === '') cleanedData.description = null;
  
  await db.update(products).set(cleanedData).where(eq(products.id, id));
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Delete related records first
  await Promise.all([
    db.delete(ingredients).where(eq(ingredients.productId, id)),
    db.delete(packaging).where(eq(packaging.productId, id)),
    db.delete(preparationSteps).where(eq(preparationSteps.productId, id)),
  ]);
  
  await db.delete(products).where(eq(products.id, id));
}

/**
 * Synchronize preparation steps across all products in a product line
 * Copies steps from the 300ml product (reference) to 500ml and 700ml
 */
export async function syncPreparationSteps(productLine: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const lineProducts = await getProductsByLine(productLine);
  if (lineProducts.length === 0) {
    throw new Error(`No products found for line: ${productLine}`);
  }
  
  // Find the 300ml product as reference (or first product if 300ml doesn't exist)
  const referenceProduct = lineProducts.find(p => p.size === '300ml') || lineProducts[0];
  
  // Get reference steps
  const referenceSteps = await db.select()
    .from(preparationSteps)
    .where(eq(preparationSteps.productId, referenceProduct.id))
    .orderBy(preparationSteps.stepNumber);
  
  if (referenceSteps.length === 0) {
    console.warn(`[Sync] No steps found for reference product ${referenceProduct.name}`);
    return { synced: 0, skipped: lineProducts.length - 1 };
  }
  
  let syncedCount = 0;
  
  // Sync to other products in the line
  for (const product of lineProducts) {
    if (product.id === referenceProduct.id) continue; // Skip reference product
    
    // Delete existing steps
    await db.delete(preparationSteps).where(eq(preparationSteps.productId, product.id));
    
    // Copy steps from reference
    const newSteps = referenceSteps.map(step => ({
      productId: product.id,
      stepNumber: step.stepNumber,
      title: step.title,
      description: step.description,
    }));
    
    await db.insert(preparationSteps).values(newSteps);
    syncedCount++;
  }
  
  return { synced: syncedCount, reference: referenceProduct.name };
}

/**
 * Validate that all products in a line have identical preparation steps
 * Returns true if all steps are identical, false otherwise
 */
export async function validatePreparationSteps(productLine: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  
  const lineProducts = await getProductsByLine(productLine);
  if (lineProducts.length <= 1) return true; // Single product, always valid
  
  // Get steps for all products
  const allSteps = await Promise.all(
    lineProducts.map(async (product) => {
      const steps = await db.select()
        .from(preparationSteps)
        .where(eq(preparationSteps.productId, product.id))
        .orderBy(preparationSteps.stepNumber);
      return { productId: product.id, productName: product.name, steps };
    })
  );
  
  // Use first product as reference
  const reference = allSteps[0];
  
  // Compare all other products with reference
  for (let i = 1; i < allSteps.length; i++) {
    const current = allSteps[i];
    
    // Check if step count matches
    if (current.steps.length !== reference.steps.length) {
      console.warn(`[Validation] Step count mismatch: ${reference.productName} has ${reference.steps.length} steps, ${current.productName} has ${current.steps.length}`);
      return false;
    }
    
    // Check if each step matches
    for (let j = 0; j < reference.steps.length; j++) {
      const refStep = reference.steps[j];
      const curStep = current.steps[j];
      
      if (refStep.stepNumber !== curStep.stepNumber ||
          refStep.title !== curStep.title ||
          refStep.description !== curStep.description) {
        console.warn(`[Validation] Step ${j + 1} mismatch between ${reference.productName} and ${current.productName}`);
        return false;
      }
    }
  }
  
  return true;
}

// Ingredient operations
export async function createIngredients(productId: number, items: Omit<InsertIngredient, 'productId'>[]) {
  const db = await getDb();
  if (!db || items.length === 0) return;
  
  const values = items.map(item => ({ ...item, productId }));
  await db.insert(ingredients).values(values);
}

export async function deleteIngredientsByProductId(productId: number) {
  const db = await getDb();
  if (!db) return;
  
  await db.delete(ingredients).where(eq(ingredients.productId, productId));
}

// Packaging operations
export async function createPackaging(productId: number, items: Omit<InsertPackaging, 'productId'>[]) {
  const db = await getDb();
  if (!db || items.length === 0) return;
  
  const values = items.map(item => ({ ...item, productId }));
  await db.insert(packaging).values(values);
}

export async function deletePackagingByProductId(productId: number) {
  const db = await getDb();
  if (!db) return;
  
  await db.delete(packaging).where(eq(packaging.productId, productId));
}

// Preparation steps operations
export async function createPreparationSteps(productId: number, steps: Omit<InsertPreparationStep, 'productId'>[]) {
  const db = await getDb();
  if (!db || steps.length === 0) return;
  
  const values = steps.map(step => ({ ...step, productId }));
  await db.insert(preparationSteps).values(values);
}

export async function deletePreparationStepsByProductId(productId: number) {
  const db = await getDb();
  if (!db) return;
  
  await db.delete(preparationSteps).where(eq(preparationSteps.productId, productId));
}


// Base Ingredients operations
export async function getAllBaseIngredients() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(baseIngredients);
}

export async function getBaseIngredientById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(baseIngredients).where(eq(baseIngredients.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createBaseIngredient(data: Omit<InsertBaseIngredient, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(baseIngredients).values(data);
  return result;
}

export async function updateBaseIngredient(id: number, data: Partial<Omit<InsertBaseIngredient, 'id' | 'createdAt' | 'updatedAt'>>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(baseIngredients).set(data).where(eq(baseIngredients.id, id));
}

export async function deleteBaseIngredient(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(baseIngredients).where(eq(baseIngredients.id, id));
}
