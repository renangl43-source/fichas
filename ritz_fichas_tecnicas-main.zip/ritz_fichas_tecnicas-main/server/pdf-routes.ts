import { Express } from 'express';
import { generateCompletePDF, generateAttendantPDF, generateFallbackPDF } from './pdf-generator';

export function registerPdfRoutes(app: Express) {
  /**
   * Rota para gerar PDF completo de um produto
   * GET /api/pdf/complete/:productId
   */
  app.get('/api/pdf/complete/:productId', async (req, res) => {
    try {
      const { productId } = req.params;
      
      // TODO: Implementar busca do produto no banco de dados
      // const product = await getProductById(parseInt(productId));
      // if (!product) {
      //   return res.status(404).json({ error: 'Produto não encontrado' });
      // }
      
      // Por enquanto, retornar erro 501 (Not Implemented)
      res.status(501).json({ 
        error: 'Endpoint não implementado. Banco de dados de produtos ainda não foi configurado.' 
      });
    } catch (error) {
      console.error('Erro ao gerar PDF completo:', error);
      res.status(500).json({ 
        error: 'Erro ao gerar PDF',
        message: error instanceof Error ? error.message : 'Erro desconhecido'
      });
    }
  });

  /**
   * Rota para gerar PDF de atendente de um produto
   * GET /api/pdf/attendant/:productId
   */
  app.get('/api/pdf/attendant/:productId', async (req, res) => {
    try {
      const { productId } = req.params;
      
      // TODO: Implementar busca do produto no banco de dados
      // const product = await getProductById(parseInt(productId));
      // if (!product) {
      //   return res.status(404).json({ error: 'Produto não encontrado' });
      // }
      
      // Por enquanto, retornar erro 501 (Not Implemented)
      res.status(501).json({ 
        error: 'Endpoint não implementado. Banco de dados de produtos ainda não foi configurado.' 
      });
    } catch (error) {
      console.error('Erro ao gerar PDF de atendente:', error);
      res.status(500).json({ 
        error: 'Erro ao gerar PDF',
        message: error instanceof Error ? error.message : 'Erro desconhecido'
      });
    }
  });

  /**
   * Rota de teste para validar geração de PDF
   * GET /api/pdf/test
   */
  app.get('/api/pdf/test', async (req, res) => {
    try {
      const mockProduct = {
        id: 1,
        name: 'Açaí Tradicional 500ml',
        code: 'ACAI-500',
        category: 'Açaís',
        description: 'Açaí tradicional de 500ml',
        totalCost: 6.50,
        suggestedPrice: 15.00,
        marginPercent: 56.67,
        ingredients: [
          {
            name: 'Açaí Ritz',
            quantity: '300,00 g',
            unitCost: 0.02,
            totalCost: 6.00
          }
        ],
        packaging: [
          {
            name: 'Copo 500ml',
            quantity: 1,
            unitCost: 0.50,
            totalCost: 0.50
          }
        ],
        steps: [
          {
            stepNumber: 1,
            title: 'BASE - PRIMEIRA CAMADA',
            description: 'Adicionar 300g de açaí Ritz no copo'
          }
        ],
        checklist: [
          'Produto montado conforme o padrão',
          'Embalagem adequada',
          'Itens descartáveis inclusos',
          'Qualidade visual verificada'
        ]
      };

      const pdfBuffer = await generateCompletePDF(mockProduct);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename="teste-ficha-completa.pdf"');
      res.send(pdfBuffer);
    } catch (error) {
      console.error('Erro ao gerar PDF de teste:', error);
      res.status(500).json({ 
        error: 'Erro ao gerar PDF de teste',
        message: error instanceof Error ? error.message : 'Erro desconhecido'
      });
    }
  });

  /**
   * Rota de teste para validar geração de PDF de atendente
   * GET /api/pdf/test-attendant
   */
  app.get('/api/pdf/test-attendant', async (req, res) => {
    try {
      const mockProduct = {
        id: 1,
        name: 'Açaí Tradicional 500ml',
        code: 'ACAI-500',
        category: 'Açaís',
        description: 'Açaí tradicional de 500ml',
        totalCost: 6.50,
        suggestedPrice: 15.00,
        marginPercent: 56.67,
        ingredients: [],
        packaging: [],
        steps: [
          {
            stepNumber: 1,
            title: 'BASE - PRIMEIRA CAMADA',
            description: 'Adicionar 300g de açaí Ritz no copo'
          }
        ],
        checklist: [
          'Produto montado conforme o padrão',
          'Embalagem adequada',
          'Itens descartáveis inclusos',
          'Qualidade visual verificada'
        ]
      };

      const pdfBuffer = await generateAttendantPDF(mockProduct);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'attachment; filename="teste-ficha-atendente.pdf"');
      res.send(pdfBuffer);
    } catch (error) {
      console.error('Erro ao gerar PDF de atendente de teste:', error);
      res.status(500).json({ 
        error: 'Erro ao gerar PDF de atendente',
        message: error instanceof Error ? error.message : 'Erro desconhecido'
      });
    }
  });
}
