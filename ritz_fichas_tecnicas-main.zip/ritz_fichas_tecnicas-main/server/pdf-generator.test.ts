import { describe, it, expect } from 'vitest';
import { generateCompletePDF, generateAttendantPDF, generateFallbackPDF, ProductData } from './pdf-generator';

const mockProduct: ProductData = {
  id: 1,
  name: 'Açaí Tradicional 500ml',
  code: 'ACAI-500',
  category: 'Açaís',
  description: 'Açaí tradicional de 500ml',
  totalCost: 6.50,
  suggestedPrice: 15.00,
  marginPercent: 56.67,
  ingredients: [
    {
      name: 'Açaí Ritz',
      quantity: '300,00 g',
      unitCost: 0.02,
      totalCost: 6.00
    }
  ],
  packaging: [
    {
      name: 'Copo 500ml',
      quantity: 1,
      unitCost: 0.50,
      totalCost: 0.50
    }
  ],
  steps: [
    {
      stepNumber: 1,
      title: 'BASE - PRIMEIRA CAMADA',
      description: 'Adicionar 300g de açaí Ritz no copo'
    }
  ],
  checklist: [
    'Produto montado conforme o padrão',
    'Embalagem adequada',
    'Itens descartáveis inclusos',
    'Qualidade visual verificada'
  ]
};

describe('PDF Generator', () => {
  describe('generateCompletePDF', () => {
    it('deve gerar um PDF completo válido', async () => {
      const pdfBuffer = await generateCompletePDF(mockProduct);
      
      expect(pdfBuffer).toBeInstanceOf(Buffer);
      expect(pdfBuffer.length).toBeGreaterThan(0);
      
      // Verificar se é um PDF válido (começa com %PDF)
      const pdfSignature = pdfBuffer.toString('utf-8', 0, 4);
      expect(pdfSignature).toBe('%PDF');
    });

    it('deve gerar PDF com tamanho razoável', async () => {
      const pdfBuffer = await generateCompletePDF(mockProduct);
      
      // PDF deve ter entre 1KB e 500KB
      expect(pdfBuffer.length).toBeGreaterThan(1024);
      expect(pdfBuffer.length).toBeLessThan(500 * 1024);
    });
  });

  describe('generateAttendantPDF', () => {
    it('deve gerar um PDF de atendente válido', async () => {
      const pdfBuffer = await generateAttendantPDF(mockProduct);
      
      expect(pdfBuffer).toBeInstanceOf(Buffer);
      expect(pdfBuffer.length).toBeGreaterThan(0);
      
      // Verificar se é um PDF válido
      const pdfSignature = pdfBuffer.toString('utf-8', 0, 4);
      expect(pdfSignature).toBe('%PDF');
    });

    it('PDF de atendente deve ser menor que PDF completo', async () => {
      const completePdf = await generateCompletePDF(mockProduct);
      const attendantPdf = await generateAttendantPDF(mockProduct);
      
      // PDF de atendente deve ser significativamente menor
      expect(attendantPdf.length).toBeLessThan(completePdf.length);
    });
  });

  describe('generateFallbackPDF', () => {
    it('deve gerar um PDF fallback válido', async () => {
      const pdfBuffer = await generateFallbackPDF('Produto Teste', 'Erro de teste');
      
      expect(pdfBuffer).toBeInstanceOf(Buffer);
      expect(pdfBuffer.length).toBeGreaterThan(0);
      
      // Verificar se é um PDF válido
      const pdfSignature = pdfBuffer.toString('utf-8', 0, 4);
      expect(pdfSignature).toBe('%PDF');
    });
  });

  describe('Error Handling', () => {
    it('deve gerar PDFs sem erros com dados válidos', async () => {
      // Testar que não há erros com dados válidos
      const completePdf = await generateCompletePDF(mockProduct);
      const attendantPdf = await generateAttendantPDF(mockProduct);
      const fallbackPdf = await generateFallbackPDF('Teste', 'Erro');
      
      expect(completePdf.length).toBeGreaterThan(0);
      expect(attendantPdf.length).toBeGreaterThan(0);
      expect(fallbackPdf.length).toBeGreaterThan(0);
    });
  });
});
